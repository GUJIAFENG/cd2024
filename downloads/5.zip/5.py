﻿# NX 1872
# Journal created by Admin on Thu Jun 13 16:38:11 2024 台北標準時間

#
import math
import NXOpen
import NXOpen.Annotations
import NXOpen.Assemblies
import NXOpen.Drawings
import NXOpen.Features
import NXOpen.GeometricUtilities
import NXOpen.Preferences
def main() : 

    theSession  = NXOpen.Session.GetSession()
    markId1 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "起點")
    
    fileNew1 = theSession.Parts.FileNew()
    
    theSession.SetUndoMarkName(markId1, "新建 對話方塊")
    
    markId2 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "新建")
    
    theSession.DeleteUndoMark(markId2, None)
    
    markId3 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "新建")
    
    fileNew1.TemplateFileName = "model-plain-1-mm-template.prt"
    
    fileNew1.UseBlankTemplate = False
    
    fileNew1.ApplicationName = "ModelTemplate"
    
    fileNew1.Units = NXOpen.Part.Units.Millimeters
    
    fileNew1.RelationType = ""
    
    fileNew1.UsesMasterModel = "No"
    
    fileNew1.TemplateType = NXOpen.FileNewTemplateType.Item
    
    fileNew1.TemplatePresentationName = "模型"
    
    fileNew1.ItemType = ""
    
    fileNew1.Specialization = ""
    
    fileNew1.SetCanCreateAltrep(False)
    
    fileNew1.NewFileName = "C:\\Program Files\\Siemens\\NX1872\\UGII\\model2.prt"
    
    fileNew1.MasterFileName = ""
    
    fileNew1.MakeDisplayedPart = True
    
    fileNew1.DisplayPartOption = NXOpen.DisplayPartOption.AllowAdditional
    
    # User Function call - UF_PART_ask_part_name
    
    nXObject1 = fileNew1.Commit()
    
    workPart = theSession.Parts.Work
    displayPart = theSession.Parts.Display
    theSession.DeleteUndoMark(markId3, None)
    
    fileNew1.Destroy()
    
    theSession.ApplicationSwitchImmediate("UG_APP_MODELING")
    
    markId4 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "起點")
    
    sketchInPlaceBuilder1 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin1 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal1 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane1 = workPart.Planes.CreatePlane(origin1, normal1, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder1.PlaneReference = plane1
    
    unit1 = workPart.UnitCollection.FindObject("MilliMeter")
    expression1 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression2 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder1 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchAlongPathBuilder1.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId4, "建立草圖 對話方塊")
    
    sketchInPlaceBuilder1.OriginOptionInfer = NXOpen.OriginMethod.WorkPartOrigin
    
    markId5 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "建立草圖")
    
    theSession.DeleteUndoMark(markId5, None)
    
    markId6 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "建立草圖")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject2 = sketchInPlaceBuilder1.Commit()
    
    sketch1 = nXObject2
    feature1 = sketch1.Feature
    
    markId7 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs1 = theSession.UpdateManager.DoUpdate(markId7)
    
    sketch1.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId6, None)
    
    theSession.SetUndoMarkName(markId4, "建立草圖")
    
    sketchInPlaceBuilder1.Destroy()
    
    sketchAlongPathBuilder1.Destroy()
    
    try:
        # 運算式仍然在使用中。
        workPart.Expressions.Delete(expression2)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # 運算式仍然在使用中。
        workPart.Expressions.Delete(expression1)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane1.DestroyPlane()
    
    markId8 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId9 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    theSession.SetUndoMarkVisibility(markId9, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using From Center method 
    # ----------------------------------------------
    startPoint1 = NXOpen.Point3d(-41.593275420475635, -49.000000000000064, 0.0)
    endPoint1 = NXOpen.Point3d(-41.593275420475585, 48.999999999999936, 0.0)
    line1 = workPart.Curves.CreateLine(startPoint1, endPoint1)
    
    startPoint2 = NXOpen.Point3d(-41.593275420475585, 48.999999999999936, 0.0)
    endPoint2 = NXOpen.Point3d(41.593275420475699, 49.0, 0.0)
    line2 = workPart.Curves.CreateLine(startPoint2, endPoint2)
    
    startPoint3 = NXOpen.Point3d(41.593275420475699, 49.0, 0.0)
    endPoint3 = NXOpen.Point3d(41.593275420475649, -49.0, 0.0)
    line3 = workPart.Curves.CreateLine(startPoint3, endPoint3)
    
    startPoint4 = NXOpen.Point3d(41.593275420475649, -49.0, 0.0)
    endPoint4 = NXOpen.Point3d(-41.593275420475635, -49.000000000000064, 0.0)
    line4 = workPart.Curves.CreateLine(startPoint4, endPoint4)
    
    theSession.ActiveSketch.AddGeometry(line1, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line2, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line3, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line4, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_1 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_1.Geometry = line1
    geom1_1.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_1.SplineDefiningPointIndex = 0
    geom2_1 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_1.Geometry = line2
    geom2_1.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_1.SplineDefiningPointIndex = 0
    sketchGeometricConstraint1 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_1, geom2_1)
    
    geom1_2 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_2.Geometry = line2
    geom1_2.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_2.SplineDefiningPointIndex = 0
    geom2_2 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_2.Geometry = line3
    geom2_2.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_2.SplineDefiningPointIndex = 0
    sketchGeometricConstraint2 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_2, geom2_2)
    
    geom1_3 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_3.Geometry = line3
    geom1_3.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_3.SplineDefiningPointIndex = 0
    geom2_3 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_3.Geometry = line4
    geom2_3.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_3.SplineDefiningPointIndex = 0
    sketchGeometricConstraint3 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_3, geom2_3)
    
    geom1_4 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_4.Geometry = line4
    geom1_4.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_4.SplineDefiningPointIndex = 0
    geom2_4 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_4.Geometry = line1
    geom2_4.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_4.SplineDefiningPointIndex = 0
    sketchGeometricConstraint4 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_4, geom2_4)
    
    geom1 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1.Geometry = line2
    geom1.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom1.SplineDefiningPointIndex = 0
    sketchGeometricConstraint5 = theSession.ActiveSketch.CreateHorizontalConstraint(geom1)
    
    conGeom1_1 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_1.Geometry = line1
    conGeom1_1.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_1.SplineDefiningPointIndex = 0
    conGeom2_1 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_1.Geometry = line2
    conGeom2_1.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_1.SplineDefiningPointIndex = 0
    sketchGeometricConstraint6 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_1, conGeom2_1)
    
    conGeom1_2 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_2.Geometry = line2
    conGeom1_2.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_2.SplineDefiningPointIndex = 0
    conGeom2_2 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_2.Geometry = line3
    conGeom2_2.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_2.SplineDefiningPointIndex = 0
    sketchGeometricConstraint7 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_2, conGeom2_2)
    
    conGeom1_3 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_3.Geometry = line3
    conGeom1_3.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_3.SplineDefiningPointIndex = 0
    conGeom2_3 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_3.Geometry = line4
    conGeom2_3.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_3.SplineDefiningPointIndex = 0
    sketchGeometricConstraint8 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_3, conGeom2_3)
    
    conGeom1_4 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_4.Geometry = line4
    conGeom1_4.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_4.SplineDefiningPointIndex = 0
    conGeom2_4 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_4.Geometry = line1
    conGeom2_4.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_4.SplineDefiningPointIndex = 0
    sketchGeometricConstraint9 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_4, conGeom2_4)
    
    conGeom1_5 = NXOpen.Sketch.ConstraintGeometry()
    
    datumCsys1 = workPart.Features.FindObject("SKETCH(1:1B)")
    point1 = datumCsys1.FindObject("POINT 1")
    conGeom1_5.Geometry = point1
    conGeom1_5.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_5.SplineDefiningPointIndex = 0
    conGeom2_5 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_5.Geometry = line1
    conGeom2_5.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_5.SplineDefiningPointIndex = 0
    sketchGeometricConstraint10 = theSession.ActiveSketch.CreateMidpointConstraint(conGeom1_5, conGeom2_5)
    
    conGeom1_6 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_6.Geometry = point1
    conGeom1_6.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_6.SplineDefiningPointIndex = 0
    conGeom2_6 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_6.Geometry = line2
    conGeom2_6.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_6.SplineDefiningPointIndex = 0
    sketchGeometricConstraint11 = theSession.ActiveSketch.CreateMidpointConstraint(conGeom1_6, conGeom2_6)
    
    dimObject1_1 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_1.Geometry = line1
    dimObject1_1.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_1.AssocValue = 0
    dimObject1_1.HelpPoint.X = 0.0
    dimObject1_1.HelpPoint.Y = 0.0
    dimObject1_1.HelpPoint.Z = 0.0
    dimObject1_1.View = NXOpen.NXObject.Null
    dimObject2_1 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_1.Geometry = line1
    dimObject2_1.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_1.AssocValue = 0
    dimObject2_1.HelpPoint.X = 0.0
    dimObject2_1.HelpPoint.Y = 0.0
    dimObject2_1.HelpPoint.Z = 0.0
    dimObject2_1.View = NXOpen.NXObject.Null
    dimOrigin1 = NXOpen.Point3d(-31.5590457998549, -6.9041524051181073e-14, 0.0)
    sketchDimensionalConstraint1 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_1, dimObject2_1, dimOrigin1, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint1 = sketchDimensionalConstraint1
    dimension1 = sketchHelpedDimensionalConstraint1.AssociatedDimension
    
    expression3 = sketchHelpedDimensionalConstraint1.AssociatedExpression
    
    dimObject1_2 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_2.Geometry = line2
    dimObject1_2.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_2.AssocValue = 0
    dimObject1_2.HelpPoint.X = 0.0
    dimObject1_2.HelpPoint.Y = 0.0
    dimObject1_2.HelpPoint.Z = 0.0
    dimObject1_2.View = NXOpen.NXObject.Null
    dimObject2_2 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_2.Geometry = line2
    dimObject2_2.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_2.AssocValue = 0
    dimObject2_2.HelpPoint.X = 0.0
    dimObject2_2.HelpPoint.Y = 0.0
    dimObject2_2.HelpPoint.Z = 0.0
    dimObject2_2.View = NXOpen.NXObject.Null
    dimOrigin2 = NXOpen.Point3d(6.4557134605028916e-14, 38.965770379379265, 0.0)
    sketchDimensionalConstraint2 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_2, dimObject2_2, dimOrigin2, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint2 = sketchDimensionalConstraint2
    dimension2 = sketchHelpedDimensionalConstraint2.AssociatedDimension
    
    expression4 = sketchHelpedDimensionalConstraint2.AssociatedExpression
    
    dimObject1_3 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_3.Geometry = line1
    dimObject1_3.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_3.AssocValue = 0
    dimObject1_3.HelpPoint.X = -41.593275420475635
    dimObject1_3.HelpPoint.Y = -49.000000000000064
    dimObject1_3.HelpPoint.Z = 0.0
    dimObject1_3.View = NXOpen.NXObject.Null
    dimObject2_3 = NXOpen.Sketch.DimensionGeometry()
    
    datumAxis1 = workPart.Datums.FindObject("SKETCH(1:1B) X axis")
    dimObject2_3.Geometry = datumAxis1
    dimObject2_3.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_3.AssocValue = 0
    dimObject2_3.HelpPoint.X = 28.574999999999999
    dimObject2_3.HelpPoint.Y = 0.0
    dimObject2_3.HelpPoint.Z = 0.0
    dimObject2_3.View = NXOpen.NXObject.Null
    dimOrigin3 = NXOpen.Point3d(-34.498003611751784, -7.0952718087238242, 0.0)
    sketchDimensionalConstraint3 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.AngularDim, dimObject1_3, dimObject2_3, dimOrigin3, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    dimension3 = sketchDimensionalConstraint3.AssociatedDimension
    
    expression5 = sketchDimensionalConstraint3.AssociatedExpression
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms1 = [NXOpen.SmartObject.Null] * 4 
    geoms1[0] = line1
    geoms1[1] = line2
    geoms1[2] = line3
    geoms1[3] = line4
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms1)
    
    geoms2 = [NXOpen.SmartObject.Null] * 4 
    geoms2[0] = line1
    geoms2[1] = line2
    geoms2[2] = line3
    geoms2[3] = line4
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms2)
    
    markId10 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "起點")
    
    parallelDimension1 = dimension2
    sketchLinearDimensionBuilder1 = workPart.Sketches.CreateLinearDimensionBuilder(parallelDimension1)
    
    sketchLinearDimensionBuilder1.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Inferred
    
    sketchLinearDimensionBuilder1.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId10, "線性尺寸 對話方塊")
    
    sketchLinearDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits1 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits2 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder1.Style.OrdinateStyle.DoglegCreationOption = NXOpen.Annotations.OrdinateDoglegCreationOption.No
    
    dimensionlinearunits3 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits4 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits5 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits6 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder1.Measurement.Direction = NXOpen.Direction.Null
    
    sketchLinearDimensionBuilder1.Measurement.DirectionView = NXOpen.View.Null
    
    sketchLinearDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits7 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits8 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits9 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits10 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits11 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits12 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits13 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits14 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits15 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits16 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits17 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits18 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    markId11 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    theSession.DeleteUndoMark(markId11, None)
    
    markId12 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    sketchLinearDimensionBuilder1.Driving.ExpressionValue.SetFormula("90")
    
    sketchLinearDimensionBuilder1.Driving.ExpressionMode = NXOpen.Annotations.DrivingValueBuilder.DrivingExpressionMode.KeepExpression
    
    sketchLinearDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    nXObject3 = sketchLinearDimensionBuilder1.Commit()
    
    point1_1 = NXOpen.Point3d(-45.000000000000632, 53.013377227669551, 0.0)
    point2_1 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder1.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line2, NXOpen.View.Null, point1_1, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_1)
    
    point1_2 = NXOpen.Point3d(45.00000000000076, 53.013377227669615, 0.0)
    point2_2 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder1.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line2, NXOpen.View.Null, point1_2, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_2)
    
    sketchLinearDimensionBuilder1.Driving.ExpressionValue.SetFormula("90")
    
    theSession.SetUndoMarkName(markId12, "線性尺寸 - =")
    
    theSession.SetUndoMarkVisibility(markId12, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId10, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId13 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    markId14 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    nXObject4 = sketchLinearDimensionBuilder1.Commit()
    
    theSession.DeleteUndoMark(markId14, None)
    
    theSession.SetUndoMarkName(markId10, "線性尺寸")
    
    expression6 = sketchLinearDimensionBuilder1.Driving.ExpressionValue
    sketchLinearDimensionBuilder1.Destroy()
    
    theSession.DeleteUndoMark(markId13, None)
    
    theSession.SetUndoMarkVisibility(markId10, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId12, None)
    
    markId15 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "起點")
    
    parallelDimension2 = dimension1
    sketchLinearDimensionBuilder2 = workPart.Sketches.CreateLinearDimensionBuilder(parallelDimension2)
    
    sketchLinearDimensionBuilder2.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Inferred
    
    sketchLinearDimensionBuilder2.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId15, "線性尺寸 對話方塊")
    
    sketchLinearDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits19 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits20 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder2.Style.OrdinateStyle.DoglegCreationOption = NXOpen.Annotations.OrdinateDoglegCreationOption.No
    
    dimensionlinearunits21 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits22 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits23 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits24 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder2.Measurement.Direction = NXOpen.Direction.Null
    
    sketchLinearDimensionBuilder2.Measurement.DirectionView = NXOpen.View.Null
    
    sketchLinearDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits25 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits26 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits27 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits28 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits29 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits30 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits31 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits32 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits33 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits34 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits35 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits36 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    markId16 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    theSession.DeleteUndoMark(markId16, None)
    
    markId17 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    sketchLinearDimensionBuilder2.Driving.ExpressionValue.SetFormula("110")
    
    sketchLinearDimensionBuilder2.Driving.ExpressionMode = NXOpen.Annotations.DrivingValueBuilder.DrivingExpressionMode.KeepExpression
    
    sketchLinearDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    nXObject5 = sketchLinearDimensionBuilder2.Commit()
    
    point1_3 = NXOpen.Point3d(-45.000000000000021, -54.999999999999993, 0.0)
    point2_3 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder2.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line1, NXOpen.View.Null, point1_3, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_3)
    
    point1_4 = NXOpen.Point3d(-45.0, 55.000000000000007, 0.0)
    point2_4 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder2.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line1, NXOpen.View.Null, point1_4, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_4)
    
    sketchLinearDimensionBuilder2.Driving.ExpressionValue.SetFormula("110")
    
    theSession.SetUndoMarkName(markId17, "線性尺寸 - =")
    
    theSession.SetUndoMarkVisibility(markId17, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId15, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId18 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    sketchLinearDimensionBuilder2.Origin.SetInferRelativeToGeometryFromLeader(False)
    
    assocOrigin1 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin1.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin1.View = NXOpen.View.Null
    assocOrigin1.ViewOfGeometry = workPart.ModelingViews.WorkView
    point2 = workPart.Points.FindObject("ENTITY 2 4")
    assocOrigin1.PointOnGeometry = point2
    assocOrigin1.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin1.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin1.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin1.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin1.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin1.DimensionLine = 0
    assocOrigin1.AssociatedView = NXOpen.View.Null
    assocOrigin1.AssociatedPoint = NXOpen.Point.Null
    assocOrigin1.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin1.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin1.XOffsetFactor = 0.0
    assocOrigin1.YOffsetFactor = 0.0
    assocOrigin1.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchLinearDimensionBuilder2.Origin.SetAssociativeOrigin(assocOrigin1)
    
    point3 = NXOpen.Point3d(67.257211318216036, -20.35415605682854, 0.0)
    sketchLinearDimensionBuilder2.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point3)
    
    sketchLinearDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder2.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchLinearDimensionBuilder2.Style.DimensionStyle.TextCentered = False
    
    dimensionlinearunits37 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits38 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits39 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits40 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits41 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits42 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits43 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits44 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits45 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits46 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits47 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits48 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    theSession.SetUndoMarkName(markId18, "線性尺寸 - 指定位置")
    
    theSession.SetUndoMarkVisibility(markId18, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId15, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId19 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    markId20 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    nXObject6 = sketchLinearDimensionBuilder2.Commit()
    
    theSession.DeleteUndoMark(markId20, None)
    
    theSession.SetUndoMarkName(markId15, "線性尺寸")
    
    expression7 = sketchLinearDimensionBuilder2.Driving.ExpressionValue
    sketchLinearDimensionBuilder2.Destroy()
    
    theSession.DeleteUndoMark(markId19, None)
    
    theSession.SetUndoMarkVisibility(markId15, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId18, None)
    
    theSession.DeleteUndoMark(markId17, None)
    
    rotMatrix1 = NXOpen.Matrix3x3()
    
    rotMatrix1.Xx = 0.55579943004826327
    rotMatrix1.Xy = 0.13470723566578913
    rotMatrix1.Xz = 0.82032978381703858
    rotMatrix1.Yx = -0.49528603979030877
    rotMatrix1.Yy = 0.84618723417905417
    rotMatrix1.Yz = 0.19661867536233282
    rotMatrix1.Zx = -0.66766663264451054
    rotMatrix1.Zy = -0.51557843765201072
    rotMatrix1.Zz = 0.53702899575484253
    translation1 = NXOpen.Point3d(6.4305905104304095, 7.170143225548478, 9.6656578186770723)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix1, translation1, 0.89692984317447444)
    
    markId21 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "起點")
    
    extrudeBuilder1 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section1 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder1.Section = section1
    
    extrudeBuilder1.AllowSelfIntersectingSection(True)
    
    unit2 = extrudeBuilder1.Draft.FrontDraftAngle.Units
    
    expression8 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder1.DistanceTolerance = 0.01
    
    extrudeBuilder1.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies1 = [NXOpen.Body.Null] * 1 
    targetBodies1[0] = NXOpen.Body.Null
    extrudeBuilder1.BooleanOperation.SetTargetBodies(targetBodies1)
    
    extrudeBuilder1.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder1.Limits.EndExtend.Value.SetFormula("25")
    
    extrudeBuilder1.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder1.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder1.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder1.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder1 = extrudeBuilder1.SmartVolumeProfile
    
    smartVolumeProfileBuilder1.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder1.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId21, "拉伸 對話方塊")
    
    section1.DistanceTolerance = 0.01
    
    section1.ChainingTolerance = 0.0094999999999999998
    
    section1.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId22 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    curves1 = [NXOpen.ICurve.Null] * 4 
    curves1[0] = line2
    curves1[1] = line3
    curves1[2] = line1
    curves1[3] = line4
    seedPoint1 = NXOpen.Point3d(-15.000000000000012, -18.333333333333339, 0.0)
    regionBoundaryRule1 = workPart.ScRuleFactory.CreateRuleRegionBoundary(theSession.ActiveSketch, curves1, seedPoint1, 0.01)
    
    section1.AllowSelfIntersection(True)
    
    rules1 = [None] * 1 
    rules1[0] = regionBoundaryRule1
    helpPoint1 = NXOpen.Point3d(0.0, 0.0, 0.0)
    section1.AddToSection(rules1, NXOpen.NXObject.Null, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint1, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId22, None)
    
    markId23 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId24 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    theSession.DeleteUndoMark(markId24, None)
    
    direction1 = workPart.Directions.CreateDirection(theSession.ActiveSketch, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder1.Direction = direction1
    
    expression9 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId23, None)
    
    rotMatrix2 = NXOpen.Matrix3x3()
    
    rotMatrix2.Xx = -0.15642385603994952
    rotMatrix2.Xy = -0.98491199064001689
    rotMatrix2.Xz = -0.074026670566214287
    rotMatrix2.Yx = 0.008189544507172344
    rotMatrix2.Yy = -0.076240076586310268
    rotMatrix2.Yz = 0.99705585705259347
    rotMatrix2.Zx = -0.98765606798235306
    rotMatrix2.Zy = 0.15535707713406299
    rotMatrix2.Zz = 0.019991747347405473
    translation2 = NXOpen.Point3d(27.920740535624653, -10.12402294226769, 20.761037620233338)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix2, translation2, 0.89692984317447444)
    
    extrudeBuilder1.Limits.EndExtend.Value.SetFormula("30")
    
    extrudeBuilder1.Limits.EndExtend.Value.SetFormula("40")
    
    markId25 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "拉伸")
    
    theSession.DeleteUndoMark(markId25, None)
    
    markId26 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "拉伸")
    
    extrudeBuilder1.ParentFeatureInternal = False
    
    markId27 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    feature2 = extrudeBuilder1.CommitFeature()
    
    theSession.DeleteUndoMark(markId26, None)
    
    theSession.SetUndoMarkName(markId21, "拉伸")
    
    expression10 = extrudeBuilder1.Limits.StartExtend.Value
    expression11 = extrudeBuilder1.Limits.EndExtend.Value
    extrudeBuilder1.Destroy()
    
    workPart.Expressions.Delete(expression8)
    
    workPart.Expressions.Delete(expression9)
    
    rotMatrix3 = NXOpen.Matrix3x3()
    
    rotMatrix3.Xx = -0.28987029644801088
    rotMatrix3.Xy = -0.95701086994491447
    rotMatrix3.Xz = -0.010266744587708234
    rotMatrix3.Yx = 0.34580117766979057
    rotMatrix3.Yy = -0.11473074625806592
    rotMatrix3.Yz = 0.93126709454659573
    rotMatrix3.Zx = -0.89241064357129662
    rotMatrix3.Zy = 0.26639641639923395
    rotMatrix3.Zz = 0.36419252129926788
    translation3 = NXOpen.Point3d(26.645542016054531, -8.8082476921477308, 13.87702214119609)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix3, translation3, 0.89692984317447444)
    
    markId28 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "起點")
    
    sketchInPlaceBuilder2 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin2 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal2 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane2 = workPart.Planes.CreatePlane(origin2, normal2, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder2.PlaneReference = plane2
    
    expression12 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression13 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder2 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchInPlaceBuilder2.OriginOptionInfer = NXOpen.OriginMethod.WorkPartOrigin
    
    sketchAlongPathBuilder2.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId28, "建立草圖 對話方塊")
    
    coordinates1 = NXOpen.Point3d(0.0, 0.0, 40.0)
    point4 = workPart.Points.CreatePoint(coordinates1)
    
    extrude1 = feature2
    edge1 = extrude1.FindObject("EDGE * 130 * 140 {(-45,55,40)(-45,0,40)(-45,-55,40) EXTRUDE(2)}")
    direction2 = workPart.Directions.CreateDirection(edge1, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    face1 = extrude1.FindObject("FACE 130 {(0,0,40) EXTRUDE(2)}")
    xform1 = workPart.Xforms.CreateXformByPlaneXDirPoint(face1, direction2, point4, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem1 = workPart.CoordinateSystems.CreateCoordinateSystem(xform1, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder2.Csystem = cartesianCoordinateSystem1
    
    origin3 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal3 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane3 = workPart.Planes.CreatePlane(origin3, normal3, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane3.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom2 = [NXOpen.NXObject.Null] * 1 
    geom2[0] = face1
    plane3.SetGeometry(geom2)
    
    plane3.SetFlip(False)
    
    plane3.SetExpression(None)
    
    plane3.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane3.Evaluate()
    
    origin4 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal4 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane4 = workPart.Planes.CreatePlane(origin4, normal4, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression14 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression15 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    plane4.SynchronizeToPlane(plane3)
    
    plane4.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom3 = [NXOpen.NXObject.Null] * 1 
    geom3[0] = face1
    plane4.SetGeometry(geom3)
    
    plane4.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane4.Evaluate()
    
    markId29 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "建立草圖")
    
    theSession.DeleteUndoMark(markId29, None)
    
    markId30 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "建立草圖")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject7 = sketchInPlaceBuilder2.Commit()
    
    sketch2 = nXObject7
    feature3 = sketch2.Feature
    
    markId31 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs2 = theSession.UpdateManager.DoUpdate(markId31)
    
    sketch2.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId30, None)
    
    theSession.SetUndoMarkName(markId28, "建立草圖")
    
    sketchInPlaceBuilder2.Destroy()
    
    sketchAlongPathBuilder2.Destroy()
    
    try:
        # 運算式仍然在使用中。
        workPart.Expressions.Delete(expression13)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # 運算式仍然在使用中。
        workPart.Expressions.Delete(expression12)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane2.DestroyPlane()
    
    try:
        # 運算式仍然在使用中。
        workPart.Expressions.Delete(expression15)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # 運算式仍然在使用中。
        workPart.Expressions.Delete(expression14)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane4.DestroyPlane()
    
    markId32 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId33 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    markId34 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId34, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    startPoint5 = NXOpen.Point3d(45.0, 55.0, 40.0)
    endPoint5 = NXOpen.Point3d(26.456322908664223, 47.507868131681839, 40.0)
    line5 = workPart.Curves.CreateLine(startPoint5, endPoint5)
    
    theSession.ActiveSketch.AddGeometry(line5, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_5 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_5.Geometry = line5
    geom1_5.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom1_5.SplineDefiningPointIndex = 0
    geom2_5 = NXOpen.Sketch.ConstraintGeometry()
    
    edge2 = extrude1.FindObject("EDGE * 130 * 160 {(45,-55,40)(45,0,40)(45,55,40) EXTRUDE(2)}")
    geom2_5.Geometry = edge2
    geom2_5.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom2_5.SplineDefiningPointIndex = 0
    sketchGeometricConstraint12 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_5, geom2_5)
    
    dimObject1_4 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_4.Geometry = line5
    dimObject1_4.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_4.AssocValue = 0
    dimObject1_4.HelpPoint.X = 0.0
    dimObject1_4.HelpPoint.Y = 0.0
    dimObject1_4.HelpPoint.Z = 0.0
    dimObject1_4.View = NXOpen.NXObject.Null
    dimObject2_4 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_4.Geometry = line5
    dimObject2_4.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_4.AssocValue = 0
    dimObject2_4.HelpPoint.X = 0.0
    dimObject2_4.HelpPoint.Y = 0.0
    dimObject2_4.HelpPoint.Z = 0.0
    dimObject2_4.View = NXOpen.NXObject.Null
    dimOrigin4 = NXOpen.Point3d(31.969272878598385, 60.557509763096284, 40.0)
    sketchDimensionalConstraint4 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_4, dimObject2_4, dimOrigin4, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint3 = sketchDimensionalConstraint4
    dimension4 = sketchHelpedDimensionalConstraint3.AssociatedDimension
    
    expression16 = sketchHelpedDimensionalConstraint3.AssociatedExpression
    
    dimObject1_5 = NXOpen.Sketch.DimensionGeometry()
    
    datumAxis2 = workPart.Datums.FindObject("SKETCH(3:1B) X axis")
    dimObject1_5.Geometry = datumAxis2
    dimObject1_5.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject1_5.AssocValue = 0
    dimObject1_5.HelpPoint.X = -5.4076061810222464e-15
    dimObject1_5.HelpPoint.Y = -28.574999999999996
    dimObject1_5.HelpPoint.Z = 40.0
    dimObject1_5.View = NXOpen.NXObject.Null
    dimObject2_5 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_5.Geometry = line5
    dimObject2_5.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject2_5.AssocValue = 0
    dimObject2_5.HelpPoint.X = 45.0
    dimObject2_5.HelpPoint.Y = 55.0
    dimObject2_5.HelpPoint.Z = 40.0
    dimObject2_5.View = NXOpen.NXObject.Null
    dimOrigin5 = NXOpen.Point3d(31.974564040394856, 15.251704069848156, 40.0)
    sketchDimensionalConstraint5 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.AngularDim, dimObject1_5, dimObject2_5, dimOrigin5, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    dimension5 = sketchDimensionalConstraint5.AssociatedDimension
    
    expression17 = sketchDimensionalConstraint5.AssociatedExpression
    
    theSession.ActiveSketch.Preferences.ContinuousAutoDimensioningSetting = False
    
    theSession.ActiveSketch.Update()
    
    theSession.ActiveSketch.Preferences.ContinuousAutoDimensioningSetting = True
    
    markId35 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId35, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    startPoint6 = NXOpen.Point3d(26.456322908664223, 47.507868131681839, 40.0)
    endPoint6 = NXOpen.Point3d(6.8493176481231082, 17.315727685646667, 40.0)
    line6 = workPart.Curves.CreateLine(startPoint6, endPoint6)
    
    theSession.ActiveSketch.AddGeometry(line6, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_6 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_6.Geometry = line6
    geom1_6.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom1_6.SplineDefiningPointIndex = 0
    geom2_6 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_6.Geometry = line5
    geom2_6.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom2_6.SplineDefiningPointIndex = 0
    sketchGeometricConstraint13 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_6, geom2_6)
    
    dimObject1_6 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_6.Geometry = line6
    dimObject1_6.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_6.AssocValue = 0
    dimObject1_6.HelpPoint.X = 0.0
    dimObject1_6.HelpPoint.Y = 0.0
    dimObject1_6.HelpPoint.Z = 0.0
    dimObject1_6.View = NXOpen.NXObject.Null
    dimObject2_6 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_6.Geometry = line6
    dimObject2_6.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_6.AssocValue = 0
    dimObject2_6.HelpPoint.X = 0.0
    dimObject2_6.HelpPoint.Y = 0.0
    dimObject2_6.HelpPoint.Z = 0.0
    dimObject2_6.View = NXOpen.NXObject.Null
    dimOrigin6 = NXOpen.Point3d(8.2374072235729248, 37.876831046358362, 40.0)
    sketchDimensionalConstraint6 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_6, dimObject2_6, dimOrigin6, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint4 = sketchDimensionalConstraint6
    dimension6 = sketchHelpedDimensionalConstraint4.AssociatedDimension
    
    expression18 = sketchHelpedDimensionalConstraint4.AssociatedExpression
    
    dimObject1_7 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_7.Geometry = line6
    dimObject1_7.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject1_7.AssocValue = 0
    dimObject1_7.HelpPoint.X = 6.8493176481231082
    dimObject1_7.HelpPoint.Y = 17.315727685646667
    dimObject1_7.HelpPoint.Z = 40.0
    dimObject1_7.View = NXOpen.NXObject.Null
    dimObject2_7 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_7.Geometry = line5
    dimObject2_7.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject2_7.AssocValue = 0
    dimObject2_7.HelpPoint.X = 45.0
    dimObject2_7.HelpPoint.Y = 55.0
    dimObject2_7.HelpPoint.Z = 40.0
    dimObject2_7.View = NXOpen.NXObject.Null
    dimOrigin7 = NXOpen.Point3d(32.838877827607028, 39.765209881053636, 40.0)
    sketchDimensionalConstraint7 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.AngularDim, dimObject1_7, dimObject2_7, dimOrigin7, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    dimension7 = sketchDimensionalConstraint7.AssociatedDimension
    
    expression19 = sketchDimensionalConstraint7.AssociatedExpression
    
    theSession.ActiveSketch.Preferences.ContinuousAutoDimensioningSetting = False
    
    theSession.ActiveSketch.Update()
    
    theSession.ActiveSketch.Preferences.ContinuousAutoDimensioningSetting = True
    
    markId36 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId36, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    startPoint7 = NXOpen.Point3d(6.8493176481231082, 17.315727685646667, 40.0)
    endPoint7 = NXOpen.Point3d(-23.150682351876892, 17.315727685646785, 40.0)
    line7 = workPart.Curves.CreateLine(startPoint7, endPoint7)
    
    theSession.ActiveSketch.AddGeometry(line7, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_7 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_7.Geometry = line7
    geom1_7.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom1_7.SplineDefiningPointIndex = 0
    geom2_7 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_7.Geometry = line6
    geom2_7.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom2_7.SplineDefiningPointIndex = 0
    sketchGeometricConstraint14 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_7, geom2_7)
    
    geom4 = NXOpen.Sketch.ConstraintGeometry()
    
    geom4.Geometry = line7
    geom4.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom4.SplineDefiningPointIndex = 0
    sketchGeometricConstraint15 = theSession.ActiveSketch.CreateVerticalConstraint(geom4)
    
    dimObject1_8 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_8.Geometry = line7
    dimObject1_8.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_8.AssocValue = 0
    dimObject1_8.HelpPoint.X = 0.0
    dimObject1_8.HelpPoint.Y = 0.0
    dimObject1_8.HelpPoint.Z = 0.0
    dimObject1_8.View = NXOpen.NXObject.Null
    dimObject2_8 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_8.Geometry = line7
    dimObject2_8.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_8.AssocValue = 0
    dimObject2_8.HelpPoint.X = 0.0
    dimObject2_8.HelpPoint.Y = 0.0
    dimObject2_8.HelpPoint.Z = 0.0
    dimObject2_8.View = NXOpen.NXObject.Null
    dimOrigin8 = NXOpen.Point3d(-8.1506823518768527, 27.349957306267438, 40.0)
    sketchDimensionalConstraint8 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_8, dimObject2_8, dimOrigin8, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint5 = sketchDimensionalConstraint8
    dimension8 = sketchHelpedDimensionalConstraint5.AssociatedDimension
    
    expression20 = sketchHelpedDimensionalConstraint5.AssociatedExpression
    
    theSession.ActiveSketch.Preferences.ContinuousAutoDimensioningSetting = False
    
    theSession.ActiveSketch.Update()
    
    theSession.ActiveSketch.Preferences.ContinuousAutoDimensioningSetting = True
    
    markId37 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId37, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    startPoint8 = NXOpen.Point3d(-23.150682351876892, 17.315727685646785, 40.0)
    endPoint8 = NXOpen.Point3d(-35.528985640195266, 47.953103422163743, 40.0)
    line8 = workPart.Curves.CreateLine(startPoint8, endPoint8)
    
    theSession.ActiveSketch.AddGeometry(line8, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_8 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_8.Geometry = line8
    geom1_8.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom1_8.SplineDefiningPointIndex = 0
    geom2_8 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_8.Geometry = line7
    geom2_8.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom2_8.SplineDefiningPointIndex = 0
    sketchGeometricConstraint16 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_8, geom2_8)
    
    conGeom1_7 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_7.Geometry = line8
    conGeom1_7.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_7.SplineDefiningPointIndex = 0
    conGeom2_7 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_7.Geometry = line5
    conGeom2_7.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_7.SplineDefiningPointIndex = 0
    sketchGeometricConstraint17 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_7, conGeom2_7)
    
    dimObject1_9 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_9.Geometry = line8
    dimObject1_9.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_9.AssocValue = 0
    dimObject1_9.HelpPoint.X = 0.0
    dimObject1_9.HelpPoint.Y = 0.0
    dimObject1_9.HelpPoint.Z = 0.0
    dimObject1_9.View = NXOpen.NXObject.Null
    dimObject2_9 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_9.Geometry = line8
    dimObject2_9.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_9.AssocValue = 0
    dimObject2_9.HelpPoint.X = 0.0
    dimObject2_9.HelpPoint.Y = 0.0
    dimObject2_9.HelpPoint.Z = 0.0
    dimObject2_9.View = NXOpen.NXObject.Null
    dimOrigin9 = NXOpen.Point3d(-20.036258298780716, 36.393304129638977, 40.0)
    sketchDimensionalConstraint9 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_9, dimObject2_9, dimOrigin9, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint6 = sketchDimensionalConstraint9
    dimension9 = sketchHelpedDimensionalConstraint6.AssociatedDimension
    
    expression21 = sketchHelpedDimensionalConstraint6.AssociatedExpression
    
    theSession.ActiveSketch.Preferences.ContinuousAutoDimensioningSetting = False
    
    theSession.ActiveSketch.Update()
    
    theSession.ActiveSketch.Preferences.ContinuousAutoDimensioningSetting = True
    
    markId38 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId38, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    startPoint9 = NXOpen.Point3d(-35.528985640195266, 47.953103422163743, 40.0)
    endPoint9 = NXOpen.Point3d(-44.999999999999993, 55.000000000000014, 40.0)
    line9 = workPart.Curves.CreateLine(startPoint9, endPoint9)
    
    theSession.ActiveSketch.AddGeometry(line9, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_9 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_9.Geometry = line9
    geom1_9.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom1_9.SplineDefiningPointIndex = 0
    geom2_9 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_9.Geometry = line8
    geom2_9.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom2_9.SplineDefiningPointIndex = 0
    sketchGeometricConstraint18 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_9, geom2_9)
    
    geom1_10 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_10.Geometry = line9
    geom1_10.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_10.SplineDefiningPointIndex = 0
    geom2_10 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_10.Geometry = edge1
    geom2_10.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_10.SplineDefiningPointIndex = 0
    sketchGeometricConstraint19 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_10, geom2_10)
    
    theSession.ActiveSketch.Preferences.ContinuousAutoDimensioningSetting = False
    
    theSession.ActiveSketch.Update()
    
    theSession.ActiveSketch.Preferences.ContinuousAutoDimensioningSetting = True
    
    markId39 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    expression22 = workPart.Expressions.CreateSystemExpression("33.2004892424183")
    
    workPart.Expressions.Delete(expression22)
    
    theSession.ActiveSketch.Update()
    
    theSession.DeleteUndoMark(markId39, "Curve")
    
    scaleAboutPoint1 = NXOpen.Point3d(-46.018091954568867, 7.9646697613676878, 0.0)
    viewCenter1 = NXOpen.Point3d(46.018091954568867, -7.9646697613676878, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint1, viewCenter1)
    
    scaleAboutPoint2 = NXOpen.Point3d(-36.814473563655092, 8.0236673151556044, 0.0)
    viewCenter2 = NXOpen.Point3d(36.814473563655092, -8.0236673151556044, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint2, viewCenter2)
    
    scaleAboutPoint3 = NXOpen.Point3d(-29.451578850924072, 6.9853103684884079, 0.0)
    viewCenter3 = NXOpen.Point3d(29.451578850924072, -6.9853103684884079, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint3, viewCenter3)
    
    scaleAboutPoint4 = NXOpen.Point3d(-23.259195605345173, 6.3434169832759553, 0.0)
    viewCenter4 = NXOpen.Point3d(23.259195605345159, -6.3434169832759553, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint4, viewCenter4)
    
    scaleAboutPoint5 = NXOpen.Point3d(-16.674124641753963, 6.0413495078818649, 0.0)
    viewCenter5 = NXOpen.Point3d(16.67412464175392, -6.0413495078818746, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint5, viewCenter5)
    
    scaleAboutPoint6 = NXOpen.Point3d(0.28998477637831305, 2.2232166189005236, 0.0)
    viewCenter6 = NXOpen.Point3d(-0.28998477637835424, -2.22321661890054, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint6, viewCenter6)
    
    scaleAboutPoint7 = NXOpen.Point3d(2.6581937834680143, 1.6915778622069293, 0.0)
    viewCenter7 = NXOpen.Point3d(-2.6581937834680449, -1.6915778622069395, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint7, viewCenter7)
    
    scaleAboutPoint8 = NXOpen.Point3d(3.4737759670320294, 1.9634385900615976, 0.0)
    viewCenter8 = NXOpen.Point3d(-3.4737759670320809, -1.9634385900616105, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint8, viewCenter8)
    
    markId40 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId41 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Sketch Drag")
    
    theSession.SetUndoMarkVisibility(markId41, "Sketch Drag", NXOpen.Session.MarkVisibility.Visible)
    
    parallelDimension3 = dimension8
    theSession.UpdateManager.LogForUpdate(parallelDimension3)
    
    minorAngularDimension1 = dimension7
    theSession.UpdateManager.LogForUpdate(minorAngularDimension1)
    
    parallelDimension4 = dimension6
    theSession.UpdateManager.LogForUpdate(parallelDimension4)
    
    startPoint10 = NXOpen.Point3d(17.118447018841444, 16.568023441021786, 40.0)
    endPoint10 = NXOpen.Point3d(-22.848590227880134, 16.568023441021783, 40.0)
    line7.SetEndpoints(startPoint10, endPoint10)
    
    startPoint11 = NXOpen.Point3d(26.456322908664223, 47.507868131681839, 40.0)
    endPoint11 = NXOpen.Point3d(17.118447018841444, 16.568023441021786, 40.0)
    line6.SetEndpoints(startPoint11, endPoint11)
    
    nErrs3 = theSession.UpdateManager.DoUpdate(markId41)
    
    geoms3 = [NXOpen.SmartObject.Null] * 2 
    geoms3[0] = line7
    geoms3[1] = line6
    theSession.ActiveSketch.UpdateGeometryDisplay(geoms3)
    
    geoms4 = [NXOpen.SmartObject.Null] * 2 
    geoms4[0] = line7
    geoms4[1] = line6
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms4)
    
    geoms5 = [NXOpen.SmartObject.Null] * 2 
    geoms5[0] = line7
    geoms5[1] = line6
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms5)
    
    markId42 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId43 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Sketch Drag")
    
    theSession.SetUndoMarkVisibility(markId43, "Sketch Drag", NXOpen.Session.MarkVisibility.Visible)
    
    theSession.UpdateManager.LogForUpdate(parallelDimension4)
    
    theSession.UpdateManager.LogForUpdate(parallelDimension3)
    
    theSession.UpdateManager.LogForUpdate(minorAngularDimension1)
    
    parallelDimension5 = dimension9
    theSession.UpdateManager.LogForUpdate(parallelDimension5)
    
    startPoint12 = NXOpen.Point3d(17.745214760842462, 18.644737334356186, 40.0)
    endPoint12 = NXOpen.Point3d(-18.563273512085804, 18.64473733435619, 40.0)
    line7.SetEndpoints(startPoint12, endPoint12)
    
    startPoint13 = NXOpen.Point3d(26.456322908664223, 47.507868131681839, 40.0)
    endPoint13 = NXOpen.Point3d(17.745214760842462, 18.644737334356186, 40.0)
    line6.SetEndpoints(startPoint13, endPoint13)
    
    startPoint14 = NXOpen.Point3d(-28.202026704261002, 42.501488643633657, 40.0)
    endPoint14 = NXOpen.Point3d(-44.999999999999993, 55.000000000000014, 40.0)
    line9.SetEndpoints(startPoint14, endPoint14)
    
    startPoint15 = NXOpen.Point3d(-18.563273512085804, 18.64473733435619, 40.0)
    endPoint15 = NXOpen.Point3d(-28.202026704261002, 42.501488643633657, 40.0)
    line8.SetEndpoints(startPoint15, endPoint15)
    
    nErrs4 = theSession.UpdateManager.DoUpdate(markId43)
    
    geoms6 = [NXOpen.SmartObject.Null] * 4 
    geoms6[0] = line7
    geoms6[1] = line6
    geoms6[2] = line9
    geoms6[3] = line8
    theSession.ActiveSketch.UpdateGeometryDisplay(geoms6)
    
    geoms7 = [NXOpen.SmartObject.Null] * 4 
    geoms7[0] = line7
    geoms7[1] = line6
    geoms7[2] = line9
    geoms7[3] = line8
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms7)
    
    geoms8 = [NXOpen.SmartObject.Null] * 4 
    geoms8[0] = line7
    geoms8[1] = line6
    geoms8[2] = line9
    geoms8[3] = line8
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms8)
    
    rotMatrix4 = NXOpen.Matrix3x3()
    
    rotMatrix4.Xx = 0.025619014195326608
    rotMatrix4.Xy = -0.99880149495857906
    rotMatrix4.Xz = -0.041704193795909839
    rotMatrix4.Yx = 0.9887137543828538
    rotMatrix4.Yy = 0.031476137942092662
    rotMatrix4.Yz = -0.14647308501706555
    rotMatrix4.Zx = 0.14761022324292361
    rotMatrix4.Zy = -0.037481013977178269
    rotMatrix4.Zz = 0.98833516358845575
    translation4 = NXOpen.Point3d(32.833164891557004, -2.8476425836791459, -39.781049615464951)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix4, translation4, 1.4014528799601165)
    
    scaleAboutPoint9 = NXOpen.Point3d(3.0206747539408902, 13.215452048491587, 0.0)
    viewCenter9 = NXOpen.Point3d(-3.0206747539409546, -13.215452048491587, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint9, viewCenter9)
    
    scaleAboutPoint10 = NXOpen.Point3d(2.4165398031527121, 10.57236163879327, 0.0)
    viewCenter10 = NXOpen.Point3d(-2.4165398031527894, -10.57236163879327, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint10, viewCenter10)
    
    scaleAboutPoint11 = NXOpen.Point3d(1.9332318425221493, 8.4578893110346165, 0.0)
    viewCenter11 = NXOpen.Point3d(-1.9332318425222419, -8.4578893110346165, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint11, viewCenter11)
    
    markId44 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "起點")
    
    sketchAngularDimensionBuilder1 = workPart.Sketches.CreateAngularDimensionBuilder(minorAngularDimension1)
    
    sketchAngularDimensionBuilder1.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Inferred
    
    sketchAngularDimensionBuilder1.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId44, "角度尺寸 對話方塊")
    
    sketchAngularDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchAngularDimensionBuilder1.Style.OrdinateStyle.DoglegCreationOption = NXOpen.Annotations.OrdinateDoglegCreationOption.No
    
    sketchAngularDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchAngularDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchAngularDimensionBuilder1.FirstVector = NXOpen.Direction.Null
    
    sketchAngularDimensionBuilder1.SecondVector = NXOpen.Direction.Null
    
    sketchAngularDimensionBuilder1.FirstVector = NXOpen.Direction.Null
    
    sketchAngularDimensionBuilder1.SecondVector = NXOpen.Direction.Null
    
    markId45 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "角度尺寸")
    
    theSession.DeleteUndoMark(markId45, None)
    
    markId46 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "角度尺寸")
    
    sketchAngularDimensionBuilder1.Driving.ExpressionValue.SetFormula("120")
    
    sketchAngularDimensionBuilder1.Driving.ExpressionMode = NXOpen.Annotations.DrivingValueBuilder.DrivingExpressionMode.KeepExpression
    
    nXObject8 = sketchAngularDimensionBuilder1.Commit()
    
    point1_5 = NXOpen.Point3d(22.260389571248552, 17.652251105491551, 40.0)
    point2_5 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchAngularDimensionBuilder1.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line6, NXOpen.View.Null, point1_5, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_5)
    
    point1_6 = NXOpen.Point3d(45.0, 55.0, 40.0)
    point2_6 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchAngularDimensionBuilder1.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line5, NXOpen.View.Null, point1_6, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_6)
    
    sketchAngularDimensionBuilder1.Driving.ExpressionValue.SetFormula("120")
    
    theSession.SetUndoMarkName(markId46, "角度尺寸 - =")
    
    theSession.SetUndoMarkVisibility(markId46, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId44, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId47 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "角度尺寸")
    
    scaleAboutPoint12 = NXOpen.Point3d(19.235656833095824, 7.6362657779626906, 0.0)
    viewCenter12 = NXOpen.Point3d(-19.235656833095899, -7.6362657779626737, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint12, viewCenter12)
    
    scaleAboutPoint13 = NXOpen.Point3d(24.044571041369778, 10.02864018308391, 0.0)
    viewCenter13 = NXOpen.Point3d(-24.044571041369871, -10.028640183083889, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint13, viewCenter13)
    
    scaleAboutPoint14 = NXOpen.Point3d(30.055713801712244, 12.988901441946025, 0.0)
    viewCenter14 = NXOpen.Point3d(-30.055713801712308, -12.988901441945998, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint14, viewCenter14)
    
    scaleAboutPoint15 = NXOpen.Point3d(37.569642252140305, 16.802503318796472, 0.0)
    viewCenter15 = NXOpen.Point3d(-37.569642252140369, -16.802503318796408, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint15, viewCenter15)
    
    scaleAboutPoint16 = NXOpen.Point3d(46.962052815175426, 21.947090009102109, 0.0)
    viewCenter16 = NXOpen.Point3d(-46.962052815175461, -21.947090009102048, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint16, viewCenter16)
    
    sketchAngularDimensionBuilder1.Origin.SetInferRelativeToGeometryFromLeader(False)
    
    assocOrigin2 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin2.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin2.View = NXOpen.View.Null
    assocOrigin2.ViewOfGeometry = workPart.ModelingViews.WorkView
    point5 = workPart.Points.FindObject("ENTITY 2 6")
    assocOrigin2.PointOnGeometry = point5
    assocOrigin2.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin2.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin2.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin2.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin2.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin2.DimensionLine = 0
    assocOrigin2.AssociatedView = NXOpen.View.Null
    assocOrigin2.AssociatedPoint = NXOpen.Point.Null
    assocOrigin2.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin2.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin2.XOffsetFactor = 0.0
    assocOrigin2.YOffsetFactor = 0.0
    assocOrigin2.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchAngularDimensionBuilder1.Origin.SetAssociativeOrigin(assocOrigin2)
    
    point6 = NXOpen.Point3d(-2.9259850310834699, 87.772281158280762, 40.0)
    sketchAngularDimensionBuilder1.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point6)
    
    sketchAngularDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchAngularDimensionBuilder1.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchAngularDimensionBuilder1.Style.DimensionStyle.TextCentered = False
    
    theSession.SetUndoMarkName(markId47, "角度尺寸 - 指定位置")
    
    theSession.SetUndoMarkVisibility(markId47, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId44, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId48 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "角度尺寸")
    
    scaleAboutPoint17 = NXOpen.Point3d(48.377994106085154, 17.699266136372675, 0.0)
    viewCenter17 = NXOpen.Point3d(-48.377994106085204, -17.699266136372625, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint17, viewCenter17)
    
    scaleAboutPoint18 = NXOpen.Point3d(37.994424639413268, 15.339363984856321, 0.0)
    viewCenter18 = NXOpen.Point3d(-37.994424639413303, -15.339363984856261, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint18, viewCenter18)
    
    scaleAboutPoint19 = NXOpen.Point3d(29.640371023045358, 13.404244220612922, 0.0)
    viewCenter19 = NXOpen.Point3d(-29.640371023045422, -13.404244220612858, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint19, viewCenter19)
    
    scaleAboutPoint20 = NXOpen.Point3d(23.108161867648111, 11.780631540369651, 0.0)
    viewCenter20 = NXOpen.Point3d(-23.108161867648189, -11.780631540369612, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint20, viewCenter20)
    
    rotMatrix5 = NXOpen.Matrix3x3()
    
    rotMatrix5.Xx = -0.0051275577198714459
    rotMatrix5.Xy = -0.999981287549913
    rotMatrix5.Xz = 0.0033365703719873442
    rotMatrix5.Yx = 0.9710965530918948
    rotMatrix5.Yy = -0.005775624493944735
    rotMatrix5.Yz = -0.23861711324787979
    rotMatrix5.Zx = 0.23863191891462426
    rotMatrix5.Zy = 0.0020166089662581703
    rotMatrix5.Zz = 0.97110799634407552
    translation5 = NXOpen.Point3d(42.052717893504976, -0.35663960000388251, -40.690260574392369)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix5, translation5, 2.1897701249376818)
    
    markId49 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "角度尺寸")
    
    nXObject9 = sketchAngularDimensionBuilder1.Commit()
    
    theSession.DeleteUndoMark(markId49, None)
    
    theSession.SetUndoMarkName(markId44, "角度尺寸")
    
    expression23 = sketchAngularDimensionBuilder1.Driving.ExpressionValue
    sketchAngularDimensionBuilder1.Destroy()
    
    theSession.DeleteUndoMark(markId48, None)
    
    theSession.SetUndoMarkVisibility(markId44, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId47, None)
    
    theSession.DeleteUndoMark(markId46, None)
    
    markId50 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "起點")
    
    sketchLinearDimensionBuilder3 = workPart.Sketches.CreateLinearDimensionBuilder(parallelDimension3)
    
    sketchLinearDimensionBuilder3.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Inferred
    
    sketchLinearDimensionBuilder3.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId50, "線性尺寸 對話方塊")
    
    sketchLinearDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits49 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits50 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder3.Style.OrdinateStyle.DoglegCreationOption = NXOpen.Annotations.OrdinateDoglegCreationOption.No
    
    dimensionlinearunits51 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits52 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits53 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits54 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder3.Measurement.Direction = NXOpen.Direction.Null
    
    sketchLinearDimensionBuilder3.Measurement.DirectionView = NXOpen.View.Null
    
    sketchLinearDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits55 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits56 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits57 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits58 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits59 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits60 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits61 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits62 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits63 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits64 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits65 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits66 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    markId51 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    theSession.DeleteUndoMark(markId51, None)
    
    markId52 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    sketchLinearDimensionBuilder3.Driving.ExpressionValue.SetFormula("40")
    
    sketchLinearDimensionBuilder3.Driving.ExpressionMode = NXOpen.Annotations.DrivingValueBuilder.DrivingExpressionMode.KeepExpression
    
    sketchLinearDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    nXObject10 = sketchLinearDimensionBuilder3.Commit()
    
    point1_7 = NXOpen.Point3d(22.260389571248552, 17.652251105491551, 40.0)
    point2_7 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder3.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line7, NXOpen.View.Null, point1_7, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_7)
    
    point1_8 = NXOpen.Point3d(-17.739610428751462, 17.652251105491484, 40.0)
    point2_8 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder3.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line7, NXOpen.View.Null, point1_8, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_8)
    
    sketchLinearDimensionBuilder3.Driving.ExpressionValue.SetFormula("40")
    
    theSession.SetUndoMarkName(markId52, "線性尺寸 - =")
    
    theSession.SetUndoMarkVisibility(markId52, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId50, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId53 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    sketchLinearDimensionBuilder3.Origin.SetInferRelativeToGeometryFromLeader(False)
    
    assocOrigin3 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin3.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin3.View = NXOpen.View.Null
    assocOrigin3.ViewOfGeometry = workPart.ModelingViews.WorkView
    point7 = workPart.Points.FindObject("ENTITY 2 4")
    assocOrigin3.PointOnGeometry = point7
    assocOrigin3.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin3.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin3.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin3.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin3.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin3.DimensionLine = 0
    assocOrigin3.AssociatedView = NXOpen.View.Null
    assocOrigin3.AssociatedPoint = NXOpen.Point.Null
    assocOrigin3.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin3.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin3.XOffsetFactor = 0.0
    assocOrigin3.YOffsetFactor = 0.0
    assocOrigin3.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchLinearDimensionBuilder3.Origin.SetAssociativeOrigin(assocOrigin3)
    
    point8 = NXOpen.Point3d(40.231630522579472, 71.100525793746087, 40.0)
    sketchLinearDimensionBuilder3.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point8)
    
    sketchLinearDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder3.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchLinearDimensionBuilder3.Style.DimensionStyle.TextCentered = False
    
    dimensionlinearunits67 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits68 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits69 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits70 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits71 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits72 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits73 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits74 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits75 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits76 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits77 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits78 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    theSession.SetUndoMarkName(markId53, "線性尺寸 - 指定位置")
    
    theSession.SetUndoMarkVisibility(markId53, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId50, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId54 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    scaleAboutPoint21 = NXOpen.Point3d(2.1748858228374308, -16.43247066143865, 0.0)
    viewCenter21 = NXOpen.Point3d(-2.1748858228375236, 16.4324706614387, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint21, viewCenter21)
    
    scaleAboutPoint22 = NXOpen.Point3d(3.286494132287697, -11.502729463007046, 0.0)
    viewCenter22 = NXOpen.Point3d(-3.2864941322877712, 11.502729463007096, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint22, viewCenter22)
    
    scaleAboutPoint23 = NXOpen.Point3d(2.6291953058301445, -9.2021835704056247, 0.0)
    viewCenter23 = NXOpen.Point3d(-2.6291953058302302, 9.2021835704056834, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint23, viewCenter23)
    
    scaleAboutPoint24 = NXOpen.Point3d(-1.7940391498606447, -8.0422444648923044, 0.0)
    viewCenter24 = NXOpen.Point3d(1.7940391498605603, 8.042244464892363, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint24, viewCenter24)
    
    scaleAboutPoint25 = NXOpen.Point3d(-2.3198782110266758, -10.052805581115386, 0.0)
    viewCenter25 = NXOpen.Point3d(2.3198782110265967, 10.052805581115447, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint25, viewCenter25)
    
    scaleAboutPoint26 = NXOpen.Point3d(-2.8998477637833449, -12.566006976394242, 0.0)
    viewCenter26 = NXOpen.Point3d(2.8998477637832458, 12.566006976394299, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint26, viewCenter26)
    
    scaleAboutPoint27 = NXOpen.Point3d(-3.6248097047291608, -15.707508720492802, 0.0)
    viewCenter27 = NXOpen.Point3d(3.6248097047290577, 15.707508720492875, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint27, viewCenter27)
    
    markId55 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    nXObject11 = sketchLinearDimensionBuilder3.Commit()
    
    theSession.DeleteUndoMark(markId55, None)
    
    theSession.SetUndoMarkName(markId50, "線性尺寸")
    
    expression24 = sketchLinearDimensionBuilder3.Driving.ExpressionValue
    sketchLinearDimensionBuilder3.Destroy()
    
    theSession.DeleteUndoMark(markId54, None)
    
    theSession.SetUndoMarkVisibility(markId50, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId53, None)
    
    theSession.DeleteUndoMark(markId52, None)
    
    markId56 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "起點")
    
    sketchLinearDimensionBuilder4 = workPart.Sketches.CreateLinearDimensionBuilder(parallelDimension5)
    
    sketchLinearDimensionBuilder4.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Inferred
    
    sketchLinearDimensionBuilder4.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId56, "線性尺寸 對話方塊")
    
    sketchLinearDimensionBuilder4.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits79 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits80 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder4.Style.OrdinateStyle.DoglegCreationOption = NXOpen.Annotations.OrdinateDoglegCreationOption.No
    
    dimensionlinearunits81 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits82 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits83 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits84 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder4.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder4.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder4.Measurement.Direction = NXOpen.Direction.Null
    
    sketchLinearDimensionBuilder4.Measurement.DirectionView = NXOpen.View.Null
    
    sketchLinearDimensionBuilder4.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits85 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits86 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits87 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits88 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits89 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits90 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits91 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits92 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits93 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits94 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits95 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits96 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    markId57 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    theSession.DeleteUndoMark(markId57, None)
    
    markId58 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    sketchLinearDimensionBuilder4.Driving.ExpressionValue.SetFormula("30")
    
    sketchLinearDimensionBuilder4.Driving.ExpressionMode = NXOpen.Annotations.DrivingValueBuilder.DrivingExpressionMode.KeepExpression
    
    sketchLinearDimensionBuilder4.Origin.SetInferRelativeToGeometry(True)
    
    nXObject12 = sketchLinearDimensionBuilder4.Commit()
    
    point1_9 = NXOpen.Point3d(-17.739610428751465, 17.652251105491484, 40.0)
    point2_9 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder4.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line8, NXOpen.View.Null, point1_9, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_9)
    
    point1_10 = NXOpen.Point3d(-28.977808231228831, 45.467766742495108, 40.0)
    point2_10 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder4.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line8, NXOpen.View.Null, point1_10, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_10)
    
    sketchLinearDimensionBuilder4.Driving.ExpressionValue.SetFormula("30")
    
    theSession.SetUndoMarkName(markId58, "線性尺寸 - =")
    
    theSession.SetUndoMarkVisibility(markId58, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId56, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId59 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    markId60 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    nXObject13 = sketchLinearDimensionBuilder4.Commit()
    
    theSession.DeleteUndoMark(markId60, None)
    
    theSession.SetUndoMarkName(markId56, "線性尺寸")
    
    expression25 = sketchLinearDimensionBuilder4.Driving.ExpressionValue
    sketchLinearDimensionBuilder4.Destroy()
    
    theSession.DeleteUndoMark(markId59, None)
    
    theSession.SetUndoMarkVisibility(markId56, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId58, None)
    
    markId61 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "起點")
    
    sketchLinearDimensionBuilder5 = workPart.Sketches.CreateLinearDimensionBuilder(parallelDimension4)
    
    sketchLinearDimensionBuilder5.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Inferred
    
    sketchLinearDimensionBuilder5.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId61, "線性尺寸 對話方塊")
    
    sketchLinearDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits97 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits98 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder5.Style.OrdinateStyle.DoglegCreationOption = NXOpen.Annotations.OrdinateDoglegCreationOption.No
    
    dimensionlinearunits99 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits100 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits101 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits102 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder5.Measurement.Direction = NXOpen.Direction.Null
    
    sketchLinearDimensionBuilder5.Measurement.DirectionView = NXOpen.View.Null
    
    sketchLinearDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits103 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits104 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits105 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits106 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits107 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits108 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits109 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits110 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits111 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits112 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits113 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits114 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    markId62 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    theSession.DeleteUndoMark(markId62, None)
    
    markId63 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    sketchLinearDimensionBuilder5.Driving.ExpressionValue.SetFormula("20")
    
    sketchLinearDimensionBuilder5.Driving.ExpressionMode = NXOpen.Annotations.DrivingValueBuilder.DrivingExpressionMode.KeepExpression
    
    sketchLinearDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    nXObject14 = sketchLinearDimensionBuilder5.Commit()
    
    point1_11 = NXOpen.Point3d(26.456322908664223, 47.507868131681839, 40.0)
    point2_11 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder5.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line6, NXOpen.View.Null, point1_11, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_11)
    
    point1_12 = NXOpen.Point3d(23.672860889462935, 27.702506756850358, 40.0)
    point2_12 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder5.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line6, NXOpen.View.Null, point1_12, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_12)
    
    sketchLinearDimensionBuilder5.Driving.ExpressionValue.SetFormula("20")
    
    theSession.SetUndoMarkName(markId63, "線性尺寸 - =")
    
    theSession.SetUndoMarkVisibility(markId63, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId61, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId64 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    rotMatrix6 = NXOpen.Matrix3x3()
    
    rotMatrix6.Xx = 0.010428844608345506
    rotMatrix6.Xy = -0.9960340629439467
    rotMatrix6.Xz = 0.088359406151855918
    rotMatrix6.Yx = 0.99976045208715081
    rotMatrix6.Yy = 0.0120865753934298
    rotMatrix6.Yz = 0.018247003528292775
    rotMatrix6.Zx = -0.01924259968501155
    rotMatrix6.Zy = 0.088147944676167253
    rotMatrix6.Zz = 0.99592151407966556
    translation6 = NXOpen.Point3d(35.944648372441222, -10.296337695371907, -44.737534322848433)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix6, translation6, 1.7518160999501455)
    
    sketchLinearDimensionBuilder5.Driving.ExpressionValue.SetFormula("30")
    
    sketchLinearDimensionBuilder5.Driving.ExpressionValue.SetFormula("30")
    
    sketchLinearDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    nXObject15 = sketchLinearDimensionBuilder5.Commit()
    
    point1_13 = NXOpen.Point3d(26.456322908664223, 47.507868131681839, 40.0)
    point2_13 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder5.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line6, NXOpen.View.Null, point1_13, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_13)
    
    point1_14 = NXOpen.Point3d(22.281129879862284, 17.799826069434655, 40.0)
    point2_14 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder5.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line6, NXOpen.View.Null, point1_14, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_14)
    
    theSession.SetUndoMarkName(markId64, "線性尺寸 - =")
    
    theSession.SetUndoMarkVisibility(markId64, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId61, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId65 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    sketchLinearDimensionBuilder5.Origin.SetInferRelativeToGeometryFromLeader(False)
    
    assocOrigin4 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin4.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin4.View = NXOpen.View.Null
    assocOrigin4.ViewOfGeometry = workPart.ModelingViews.WorkView
    point9 = workPart.Points.FindObject("ENTITY 2 8")
    assocOrigin4.PointOnGeometry = point9
    assocOrigin4.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin4.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin4.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin4.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin4.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin4.DimensionLine = 0
    assocOrigin4.AssociatedView = NXOpen.View.Null
    assocOrigin4.AssociatedPoint = NXOpen.Point.Null
    assocOrigin4.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin4.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin4.XOffsetFactor = 0.0
    assocOrigin4.YOffsetFactor = 0.0
    assocOrigin4.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchLinearDimensionBuilder5.Origin.SetAssociativeOrigin(assocOrigin4)
    
    point10 = NXOpen.Point3d(52.281204850102689, 3.3362904373271056, 40.0)
    sketchLinearDimensionBuilder5.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point10)
    
    sketchLinearDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder5.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchLinearDimensionBuilder5.Style.DimensionStyle.TextCentered = False
    
    dimensionlinearunits115 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits116 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits117 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits118 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits119 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits120 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits121 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits122 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits123 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits124 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits125 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits126 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    theSession.SetUndoMarkName(markId65, "線性尺寸 - 指定位置")
    
    theSession.SetUndoMarkVisibility(markId65, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId61, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId66 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    rotMatrix7 = NXOpen.Matrix3x3()
    
    rotMatrix7.Xx = -0.051103399824294307
    rotMatrix7.Xy = -0.99778798658455103
    rotMatrix7.Xz = 0.042515601300532814
    rotMatrix7.Yx = 0.82230707148221616
    rotMatrix7.Yy = -0.017880938910120936
    rotMatrix7.Yz = 0.56876300179779682
    rotMatrix7.Zx = -0.56674467153802821
    rotMatrix7.Zy = 0.0640266026838857
    rotMatrix7.Zz = 0.82140189397883612
    translation7 = NXOpen.Point3d(37.456910938396973, -21.041632394155545, -36.445879162304664)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix7, translation7, 1.7518160999501455)
    
    markId67 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    nXObject16 = sketchLinearDimensionBuilder5.Commit()
    
    theSession.DeleteUndoMark(markId67, None)
    
    theSession.SetUndoMarkName(markId61, "線性尺寸")
    
    expression26 = sketchLinearDimensionBuilder5.Driving.ExpressionValue
    sketchLinearDimensionBuilder5.Destroy()
    
    theSession.DeleteUndoMark(markId66, None)
    
    theSession.SetUndoMarkVisibility(markId61, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId65, None)
    
    theSession.DeleteUndoMark(markId64, None)
    
    theSession.DeleteUndoMark(markId63, None)
    
    markId68 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId69 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId69, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    startPoint16 = NXOpen.Point3d(45.0, 55.0, 40.0)
    endPoint16 = NXOpen.Point3d(-45.0, 55.000000000000192, 40.0)
    line10 = workPart.Curves.CreateLine(startPoint16, endPoint16)
    
    theSession.ActiveSketch.AddGeometry(line10, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_11 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_11.Geometry = line10
    geom1_11.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom1_11.SplineDefiningPointIndex = 0
    geom2_11 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_11.Geometry = line5
    geom2_11.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_11.SplineDefiningPointIndex = 0
    sketchGeometricConstraint20 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_11, geom2_11)
    
    geom5 = NXOpen.Sketch.ConstraintGeometry()
    
    geom5.Geometry = line10
    geom5.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom5.SplineDefiningPointIndex = 0
    sketchGeometricConstraint21 = theSession.ActiveSketch.CreateVerticalConstraint(geom5)
    
    geom1_12 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_12.Geometry = line10
    geom1_12.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_12.SplineDefiningPointIndex = 0
    geom2_12 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_12.Geometry = line9
    geom2_12.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom2_12.SplineDefiningPointIndex = 0
    sketchGeometricConstraint22 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_12, geom2_12)
    
    theSession.ActiveSketch.Preferences.ContinuousAutoDimensioningSetting = False
    
    theSession.ActiveSketch.Update()
    
    theSession.ActiveSketch.Preferences.ContinuousAutoDimensioningSetting = True
    
    markId70 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.ActiveSketch.Update()
    
    theSession.DeleteUndoMark(markId70, "Curve")
    
    markId71 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "起點")
    
    extrudeBuilder2 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section2 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder2.Section = section2
    
    extrudeBuilder2.AllowSelfIntersectingSection(True)
    
    expression27 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder2.DistanceTolerance = 0.01
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies2 = [NXOpen.Body.Null] * 1 
    targetBodies2[0] = NXOpen.Body.Null
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies2)
    
    extrudeBuilder2.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder2.Limits.EndExtend.Value.SetFormula("40")
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies3 = [NXOpen.Body.Null] * 1 
    targetBodies3[0] = NXOpen.Body.Null
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies3)
    
    extrudeBuilder2.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder2.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder2.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder2.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder2 = extrudeBuilder2.SmartVolumeProfile
    
    smartVolumeProfileBuilder2.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder2.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId71, "拉伸 對話方塊")
    
    section2.DistanceTolerance = 0.01
    
    section2.ChainingTolerance = 0.0094999999999999998
    
    section2.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId72 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    curves2 = [NXOpen.ICurve.Null] * 6 
    curves2[0] = line5
    curves2[1] = line7
    curves2[2] = line9
    curves2[3] = line6
    curves2[4] = line10
    curves2[5] = line8
    seedPoint2 = NXOpen.Point3d(-6.7398717113628566, 36.974345302518266, 40.0)
    regionBoundaryRule2 = workPart.ScRuleFactory.CreateRuleRegionBoundary(theSession.ActiveSketch, curves2, seedPoint2, 0.01)
    
    section2.AllowSelfIntersection(True)
    
    rules2 = [None] * 1 
    rules2[0] = regionBoundaryRule2
    helpPoint2 = NXOpen.Point3d(0.0, 0.0, 0.0)
    section2.AddToSection(rules2, NXOpen.NXObject.Null, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint2, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId72, None)
    
    markId73 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId74 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    theSession.DeleteUndoMark(markId74, None)
    
    direction3 = workPart.Directions.CreateDirection(theSession.ActiveSketch, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder2.Direction = direction3
    
    targetBodies4 = [NXOpen.Body.Null] * 1 
    body1 = workPart.Bodies.FindObject("EXTRUDE(2)")
    targetBodies4[0] = body1
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies4)
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies5 = [NXOpen.Body.Null] * 1 
    targetBodies5[0] = body1
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies5)
    
    expression28 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId73, None)
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies6 = [NXOpen.Body.Null] * 1 
    targetBodies6[0] = body1
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies6)
    
    success1 = direction3.ReverseDirection()
    
    extrudeBuilder2.Direction = direction3
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies7 = [NXOpen.Body.Null] * 1 
    targetBodies7[0] = body1
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies7)
    
    rotMatrix8 = NXOpen.Matrix3x3()
    
    rotMatrix8.Xx = -0.47369290039103473
    rotMatrix8.Xy = -0.86812481009196452
    rotMatrix8.Xz = 0.14823747914047375
    rotMatrix8.Yx = 0.38058914188477172
    rotMatrix8.Yy = -0.049994073139653809
    rotMatrix8.Yz = 0.92339184408913133
    rotMatrix8.Zx = -0.79420837391616006
    rotMatrix8.Zy = 0.49382173580523914
    rotMatrix8.Zz = 0.35408071402966551
    translation8 = NXOpen.Point3d(34.198258047054736, -24.336190378919724, -38.439531005139379)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix8, translation8, 1.7518160999501455)
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies8 = [NXOpen.Body.Null] * 1 
    targetBodies8[0] = body1
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies8)
    
    extrudeBuilder2.Limits.EndExtend.Value.SetFormula("61")
    
    rotMatrix9 = NXOpen.Matrix3x3()
    
    rotMatrix9.Xx = -0.058230112969048856
    rotMatrix9.Xy = -0.9979448314558288
    rotMatrix9.Xz = -0.026746351418676362
    rotMatrix9.Yx = 0.37045915215894759
    rotMatrix9.Yy = -0.046479593646606823
    rotMatrix9.Yz = 0.9276851103451681
    rotMatrix9.Zx = -0.92702172063296073
    rotMatrix9.Zy = 0.044110778105196494
    rotMatrix9.Zz = 0.37240430815132758
    translation9 = NXOpen.Point3d(36.13365807449226, -24.385813257627568, -35.635135041320119)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix9, translation9, 1.7518160999501455)
    
    markId75 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "拉伸")
    
    theSession.DeleteUndoMark(markId75, None)
    
    markId76 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "拉伸")
    
    extrudeBuilder2.ParentFeatureInternal = False
    
    markId77 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    feature4 = extrudeBuilder2.CommitFeature()
    
    theSession.DeleteUndoMark(markId76, None)
    
    theSession.SetUndoMarkName(markId71, "拉伸")
    
    expression29 = extrudeBuilder2.Limits.StartExtend.Value
    expression30 = extrudeBuilder2.Limits.EndExtend.Value
    extrudeBuilder2.Destroy()
    
    workPart.Expressions.Delete(expression27)
    
    workPart.Expressions.Delete(expression28)
    
    rotMatrix10 = NXOpen.Matrix3x3()
    
    rotMatrix10.Xx = -0.68148711884082513
    rotMatrix10.Xy = -0.61756996273245435
    rotMatrix10.Xz = -0.39266098352735679
    rotMatrix10.Yx = -0.13596462740930065
    rotMatrix10.Yy = -0.42036159711875015
    rotMatrix10.Yz = 0.89711189255366985
    rotMatrix10.Zx = -0.71908895621298874
    rotMatrix10.Zy = 0.66475820325770607
    rotMatrix10.Zz = 0.20250334380969118
    translation10 = NXOpen.Point3d(43.451950716665849, -23.77434890179758, -32.237115754487434)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix10, translation10, 1.7518160999501455)
    
    markId78 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "起點")
    
    sketchInPlaceBuilder3 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin5 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal5 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane5 = workPart.Planes.CreatePlane(origin5, normal5, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder3.PlaneReference = plane5
    
    expression31 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression32 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder3 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchInPlaceBuilder3.OriginOptionInfer = NXOpen.OriginMethod.WorkPartOrigin
    
    sketchAlongPathBuilder3.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId78, "建立草圖 對話方塊")
    
    coordinates2 = NXOpen.Point3d(-45.000000000000007, 8.5159152457043287e-15, 0.0)
    point11 = workPart.Points.CreatePoint(coordinates2)
    
    edge3 = extrude1.FindObject("EDGE * 120 * 140 {(-45,55,0)(-45,0,0)(-45,-55,0) EXTRUDE(2)}")
    direction4 = workPart.Directions.CreateDirection(edge3, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    face2 = extrude1.FindObject("FACE 140 {(-45,0,20) EXTRUDE(2)}")
    xform2 = workPart.Xforms.CreateXformByPlaneXDirPoint(face2, direction4, point11, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem2 = workPart.CoordinateSystems.CreateCoordinateSystem(xform2, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder3.Csystem = cartesianCoordinateSystem2
    
    origin6 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal6 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane6 = workPart.Planes.CreatePlane(origin6, normal6, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane6.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom6 = [NXOpen.NXObject.Null] * 1 
    geom6[0] = face2
    plane6.SetGeometry(geom6)
    
    plane6.SetFlip(False)
    
    plane6.SetExpression(None)
    
    plane6.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane6.Evaluate()
    
    origin7 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal7 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane7 = workPart.Planes.CreatePlane(origin7, normal7, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression33 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression34 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    plane7.SynchronizeToPlane(plane6)
    
    plane7.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom7 = [NXOpen.NXObject.Null] * 1 
    geom7[0] = face2
    plane7.SetGeometry(geom7)
    
    plane7.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane7.Evaluate()
    
    markId79 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "建立草圖")
    
    theSession.DeleteUndoMark(markId79, None)
    
    markId80 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "建立草圖")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject17 = sketchInPlaceBuilder3.Commit()
    
    sketch3 = nXObject17
    feature5 = sketch3.Feature
    
    markId81 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs5 = theSession.UpdateManager.DoUpdate(markId81)
    
    sketch3.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId80, None)
    
    theSession.SetUndoMarkName(markId78, "建立草圖")
    
    sketchInPlaceBuilder3.Destroy()
    
    sketchAlongPathBuilder3.Destroy()
    
    try:
        # 運算式仍然在使用中。
        workPart.Expressions.Delete(expression32)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # 運算式仍然在使用中。
        workPart.Expressions.Delete(expression31)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane5.DestroyPlane()
    
    try:
        # 運算式仍然在使用中。
        workPart.Expressions.Delete(expression34)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # 運算式仍然在使用中。
        workPart.Expressions.Delete(expression33)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane7.DestroyPlane()
    
    markId82 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    theSession.DeleteUndoMark(markId82, "Curve")
    
    markId83 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId84 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    rotMatrix11 = NXOpen.Matrix3x3()
    
    rotMatrix11.Xx = 0.014559181159323711
    rotMatrix11.Xy = -0.99970713298929892
    rotMatrix11.Xz = -0.019330765486311664
    rotMatrix11.Yx = 0.3064665048357933
    rotMatrix11.Yy = -0.013940804891777974
    rotMatrix11.Yz = 0.95177935225171972
    rotMatrix11.Zx = -0.95177009390803224
    rotMatrix11.Zy = -0.019781360147526808
    rotMatrix11.Zz = 0.30617378420271585
    translation11 = NXOpen.Point3d(0.38661530972623337, 0.96441295496561352, -51.123475684054327)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix11, translation11, 1.7518160999501446)
    
    theSession.SetUndoMarkVisibility(markId84, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using By 2 Points method 
    # ----------------------------------------------
    startPoint17 = NXOpen.Point3d(-45.000000000000014, 55.0, 0.0)
    endPoint17 = NXOpen.Point3d(-45.000000000000014, 29.629718578629394, 0.0)
    line11 = workPart.Curves.CreateLine(startPoint17, endPoint17)
    
    startPoint18 = NXOpen.Point3d(-45.000000000000014, 29.629718578629394, 0.0)
    endPoint18 = NXOpen.Point3d(-45.000000000000014, 29.629718578629394, 40.0)
    line12 = workPart.Curves.CreateLine(startPoint18, endPoint18)
    
    startPoint19 = NXOpen.Point3d(-45.000000000000014, 29.629718578629394, 40.0)
    endPoint19 = NXOpen.Point3d(-45.000000000000014, 55.0, 40.0)
    line13 = workPart.Curves.CreateLine(startPoint19, endPoint19)
    
    startPoint20 = NXOpen.Point3d(-45.000000000000014, 55.0, 40.0)
    endPoint20 = NXOpen.Point3d(-45.000000000000014, 55.0, 0.0)
    line14 = workPart.Curves.CreateLine(startPoint20, endPoint20)
    
    theSession.ActiveSketch.AddGeometry(line11, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line12, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line13, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line14, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_13 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_13.Geometry = line11
    geom1_13.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_13.SplineDefiningPointIndex = 0
    geom2_13 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_13.Geometry = line12
    geom2_13.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_13.SplineDefiningPointIndex = 0
    sketchGeometricConstraint23 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_13, geom2_13)
    
    geom1_14 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_14.Geometry = line12
    geom1_14.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_14.SplineDefiningPointIndex = 0
    geom2_14 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_14.Geometry = line13
    geom2_14.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_14.SplineDefiningPointIndex = 0
    sketchGeometricConstraint24 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_14, geom2_14)
    
    geom1_15 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_15.Geometry = line13
    geom1_15.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_15.SplineDefiningPointIndex = 0
    geom2_15 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_15.Geometry = line14
    geom2_15.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_15.SplineDefiningPointIndex = 0
    sketchGeometricConstraint25 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_15, geom2_15)
    
    geom1_16 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_16.Geometry = line14
    geom1_16.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_16.SplineDefiningPointIndex = 0
    geom2_16 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_16.Geometry = line11
    geom2_16.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_16.SplineDefiningPointIndex = 0
    sketchGeometricConstraint26 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_16, geom2_16)
    
    geom8 = NXOpen.Sketch.ConstraintGeometry()
    
    geom8.Geometry = line11
    geom8.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom8.SplineDefiningPointIndex = 0
    sketchGeometricConstraint27 = theSession.ActiveSketch.CreateHorizontalConstraint(geom8)
    
    conGeom1_8 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_8.Geometry = line11
    conGeom1_8.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_8.SplineDefiningPointIndex = 0
    conGeom2_8 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_8.Geometry = line12
    conGeom2_8.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_8.SplineDefiningPointIndex = 0
    sketchGeometricConstraint28 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_8, conGeom2_8)
    
    conGeom1_9 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_9.Geometry = line12
    conGeom1_9.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_9.SplineDefiningPointIndex = 0
    conGeom2_9 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_9.Geometry = line13
    conGeom2_9.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_9.SplineDefiningPointIndex = 0
    sketchGeometricConstraint29 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_9, conGeom2_9)
    
    conGeom1_10 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_10.Geometry = line13
    conGeom1_10.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_10.SplineDefiningPointIndex = 0
    conGeom2_10 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_10.Geometry = line14
    conGeom2_10.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_10.SplineDefiningPointIndex = 0
    sketchGeometricConstraint30 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_10, conGeom2_10)
    
    conGeom1_11 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_11.Geometry = line14
    conGeom1_11.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_11.SplineDefiningPointIndex = 0
    conGeom2_11 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_11.Geometry = line11
    conGeom2_11.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_11.SplineDefiningPointIndex = 0
    sketchGeometricConstraint31 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_11, conGeom2_11)
    
    geom1_17 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_17.Geometry = line11
    geom1_17.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom1_17.SplineDefiningPointIndex = 0
    geom2_17 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_17.Geometry = line1
    geom2_17.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom2_17.SplineDefiningPointIndex = 0
    sketchGeometricConstraint32 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_17, geom2_17)
    
    conGeom1_12 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_12.Geometry = line13
    conGeom1_12.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    conGeom1_12.SplineDefiningPointIndex = 0
    conGeom2_12 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_12.Geometry = edge1
    conGeom2_12.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_12.SplineDefiningPointIndex = 0
    help1 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    help1.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    help1.Point.X = -45.000000000000014
    help1.Point.Y = 29.629718578629394
    help1.Point.Z = 40.0
    help1.Parameter = 0.0
    sketchHelpedGeometricConstraint1 = theSession.ActiveSketch.CreatePointOnCurveConstraint(conGeom1_12, conGeom2_12, help1)
    
    dimObject1_10 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_10.Geometry = line12
    dimObject1_10.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_10.AssocValue = 0
    dimObject1_10.HelpPoint.X = 0.0
    dimObject1_10.HelpPoint.Y = 0.0
    dimObject1_10.HelpPoint.Z = 0.0
    dimObject1_10.View = NXOpen.NXObject.Null
    dimObject2_10 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_10.Geometry = line12
    dimObject2_10.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_10.AssocValue = 0
    dimObject2_10.HelpPoint.X = 0.0
    dimObject2_10.HelpPoint.Y = 0.0
    dimObject2_10.HelpPoint.Z = 0.0
    dimObject2_10.View = NXOpen.NXObject.Null
    dimOrigin10 = NXOpen.Point3d(-45.000000000000014, 24.492193012871589, 20.0)
    sketchDimensionalConstraint10 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_10, dimObject2_10, dimOrigin10, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint7 = sketchDimensionalConstraint10
    dimension10 = sketchHelpedDimensionalConstraint7.AssociatedDimension
    
    expression35 = sketchHelpedDimensionalConstraint7.AssociatedExpression
    
    dimObject1_11 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_11.Geometry = line11
    dimObject1_11.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_11.AssocValue = 0
    dimObject1_11.HelpPoint.X = 0.0
    dimObject1_11.HelpPoint.Y = 0.0
    dimObject1_11.HelpPoint.Z = 0.0
    dimObject1_11.View = NXOpen.NXObject.Null
    dimObject2_11 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_11.Geometry = line11
    dimObject2_11.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_11.AssocValue = 0
    dimObject2_11.HelpPoint.X = 0.0
    dimObject2_11.HelpPoint.Y = 0.0
    dimObject2_11.HelpPoint.Z = 0.0
    dimObject2_11.View = NXOpen.NXObject.Null
    dimOrigin11 = NXOpen.Point3d(-45.000000000000014, 42.314859289314697, -5.1375255657578061)
    sketchDimensionalConstraint11 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_11, dimObject2_11, dimOrigin11, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint8 = sketchDimensionalConstraint11
    dimension11 = sketchHelpedDimensionalConstraint8.AssociatedDimension
    
    expression36 = sketchHelpedDimensionalConstraint8.AssociatedExpression
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms9 = [NXOpen.SmartObject.Null] * 4 
    geoms9[0] = line11
    geoms9[1] = line12
    geoms9[2] = line13
    geoms9[3] = line14
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms9)
    
    geoms10 = [NXOpen.SmartObject.Null] * 4 
    geoms10[0] = line11
    geoms10[1] = line12
    geoms10[2] = line13
    geoms10[3] = line14
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms10)
    
    markId85 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "起點")
    
    parallelDimension6 = dimension11
    sketchLinearDimensionBuilder6 = workPart.Sketches.CreateLinearDimensionBuilder(parallelDimension6)
    
    sketchLinearDimensionBuilder6.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Inferred
    
    sketchLinearDimensionBuilder6.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId85, "線性尺寸 對話方塊")
    
    sketchLinearDimensionBuilder6.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits127 = sketchLinearDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits128 = sketchLinearDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder6.Style.OrdinateStyle.DoglegCreationOption = NXOpen.Annotations.OrdinateDoglegCreationOption.No
    
    dimensionlinearunits129 = sketchLinearDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits130 = sketchLinearDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits131 = sketchLinearDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits132 = sketchLinearDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder6.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder6.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder6.Measurement.Direction = NXOpen.Direction.Null
    
    sketchLinearDimensionBuilder6.Measurement.DirectionView = NXOpen.View.Null
    
    sketchLinearDimensionBuilder6.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits133 = sketchLinearDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits134 = sketchLinearDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits135 = sketchLinearDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits136 = sketchLinearDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits137 = sketchLinearDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits138 = sketchLinearDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits139 = sketchLinearDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits140 = sketchLinearDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits141 = sketchLinearDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits142 = sketchLinearDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits143 = sketchLinearDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits144 = sketchLinearDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    markId86 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    theSession.DeleteUndoMark(markId86, None)
    
    markId87 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    sketchLinearDimensionBuilder6.Driving.ExpressionValue.SetFormula("26")
    
    sketchLinearDimensionBuilder6.Driving.ExpressionMode = NXOpen.Annotations.DrivingValueBuilder.DrivingExpressionMode.KeepExpression
    
    sketchLinearDimensionBuilder6.Origin.SetInferRelativeToGeometry(True)
    
    nXObject18 = sketchLinearDimensionBuilder6.Commit()
    
    point1_15 = NXOpen.Point3d(-45.000000000000014, 55.0, 0.0)
    point2_15 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder6.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line11, NXOpen.View.Null, point1_15, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_15)
    
    point1_16 = NXOpen.Point3d(-45.000000000000014, 29.000000000000007, 0.0)
    point2_16 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder6.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line11, NXOpen.View.Null, point1_16, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_16)
    
    sketchLinearDimensionBuilder6.Driving.ExpressionValue.SetFormula("26")
    
    theSession.SetUndoMarkName(markId87, "線性尺寸 - =")
    
    theSession.SetUndoMarkVisibility(markId87, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId85, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId88 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    markId89 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "線性尺寸")
    
    nXObject19 = sketchLinearDimensionBuilder6.Commit()
    
    theSession.DeleteUndoMark(markId89, None)
    
    theSession.SetUndoMarkName(markId85, "線性尺寸")
    
    expression37 = sketchLinearDimensionBuilder6.Driving.ExpressionValue
    sketchLinearDimensionBuilder6.Destroy()
    
    theSession.DeleteUndoMark(markId88, None)
    
    theSession.SetUndoMarkVisibility(markId85, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId87, None)
    
    markId90 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId91 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "##40Fillet")
    
    helpPoint1_1 = NXOpen.Point3d(-45.000000000000014, 55.086757750777934, 22.086757750777952)
    helpPoint2_1 = NXOpen.Point3d(-45.000000000000014, 37.086757750777927, 40.086757750777934)
    pointonarc1 = NXOpen.Point3d(-45.000000000000014, 50.131259153624811, 34.363778196734692)
    fillets1, constraints1 = theSession.ActiveSketch.Fillet(line14, line13, helpPoint1_1, helpPoint2_1, pointonarc1, 18.0, NXOpen.Sketch.TrimInputOption.TrueValue, NXOpen.Sketch.CreateDimensionOption.FalseValue, NXOpen.Sketch.AlternateSolutionOption.FalseValue)
    
    theSession.ActiveSketch.Update()
    
    rotMatrix12 = NXOpen.Matrix3x3()
    
    rotMatrix12.Xx = -0.39238601660761468
    rotMatrix12.Xy = -0.86132374646791687
    rotMatrix12.Xz = -0.32272994552920287
    rotMatrix12.Yx = 0.21239328913240865
    rotMatrix12.Yy = -0.42623343282865855
    rotMatrix12.Yz = 0.87932596428776943
    rotMatrix12.Zx = -0.89494262648637279
    rotMatrix12.Zy = 0.27648953779405705
    rotMatrix12.Zz = 0.35018742237279643
    translation12 = NXOpen.Point3d(5.155133135846949, 2.1031611612729222, -51.815237007129753)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix12, translation12, 1.7518160999501446)
    
    markId92 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "起點")
    
    extrudeBuilder3 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section3 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder3.Section = section3
    
    extrudeBuilder3.AllowSelfIntersectingSection(True)
    
    expression38 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder3.DistanceTolerance = 0.01
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies9 = [NXOpen.Body.Null] * 1 
    targetBodies9[0] = NXOpen.Body.Null
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies9)
    
    extrudeBuilder3.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder3.Limits.EndExtend.Value.SetFormula("61")
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies10 = [NXOpen.Body.Null] * 1 
    targetBodies10[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies10)
    
    extrudeBuilder3.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder3.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder3.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder3.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder3 = extrudeBuilder3.SmartVolumeProfile
    
    smartVolumeProfileBuilder3.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder3.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId92, "拉伸 對話方塊")
    
    section3.DistanceTolerance = 0.01
    
    section3.ChainingTolerance = 0.0094999999999999998
    
    section3.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId93 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    curves3 = [NXOpen.ICurve.Null] * 5 
    curves3[0] = line14
    curves3[1] = line12
    curves3[2] = fillets1[0]
    curves3[3] = line13
    curves3[4] = line11
    seedPoint3 = NXOpen.Point3d(-45.000000000000014, 38.613363523006051, 24.917777606080072)
    regionBoundaryRule3 = workPart.ScRuleFactory.CreateRuleRegionBoundary(theSession.ActiveSketch, curves3, seedPoint3, 0.01)
    
    section3.AllowSelfIntersection(True)
    
    rules3 = [None] * 1 
    rules3[0] = regionBoundaryRule3
    helpPoint3 = NXOpen.Point3d(0.0, 0.0, 0.0)
    section3.AddToSection(rules3, NXOpen.NXObject.Null, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint3, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId93, None)
    
    markId94 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId95 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    theSession.DeleteUndoMark(markId95, None)
    
    direction5 = workPart.Directions.CreateDirection(theSession.ActiveSketch, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder3.Direction = direction5
    
    expression39 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId94, None)
    
    rotMatrix13 = NXOpen.Matrix3x3()
    
    rotMatrix13.Xx = -0.97461851281101486
    rotMatrix13.Xy = -0.027233383837042241
    rotMatrix13.Xz = 0.22220957965585575
    rotMatrix13.Yx = 0.21239328913240865
    rotMatrix13.Yy = -0.42623343282865855
    rotMatrix13.Yz = 0.87932596428776943
    rotMatrix13.Zx = 0.070766130440802252
    rotMatrix13.Zy = 0.90420318709009428
    rotMatrix13.Zz = 0.42119918238115506
    translation13 = NXOpen.Point3d(-20.904975833007281, 2.1031611612729222, -23.442966384197717)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix13, translation13, 1.7518160999501446)
    
    direction6 = extrudeBuilder3.Direction
    
    success2 = direction6.ReverseDirection()
    
    extrudeBuilder3.Direction = direction6
    
    extrudeBuilder3.Limits.EndExtend.Value.SetFormula("115")
    
    rotMatrix14 = NXOpen.Matrix3x3()
    
    rotMatrix14.Xx = -0.77296716879975103
    rotMatrix14.Xy = -0.63341873185907482
    rotMatrix14.Xz = -0.036089695035292822
    rotMatrix14.Yx = 0.26319184469376278
    rotMatrix14.Yy = -0.3718946855582666
    rotMatrix14.Yz = 0.89018222614261033
    rotMatrix14.Zx = -0.57727966259378449
    rotMatrix14.Zy = 0.67858312164653933
    rotMatrix14.Zz = 0.45417302668922083
    translation14 = NXOpen.Point3d(-10.819484774382307, 3.4871246625659094, -43.710711370730515)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix14, translation14, 1.7518160999501446)
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies11 = [NXOpen.Body.Null] * 1 
    targetBodies11[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies11)
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies12 = [NXOpen.Body.Null] * 1 
    targetBodies12[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies12)
    
    markId96 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "拉伸")
    
    extrudeBuilder3.ParentFeatureInternal = False
    
    markId97 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    feature6 = extrudeBuilder3.CommitFeature()
    
    rotMatrix15 = NXOpen.Matrix3x3()
    
    rotMatrix15.Xx = -0.63794516776901233
    rotMatrix15.Xy = -0.76184004653336934
    rotMatrix15.Xz = -0.11236416874698422
    rotMatrix15.Yx = 0.20567552187053767
    rotMatrix15.Yy = -0.3091721305624972
    rotMatrix15.Yz = 0.92849888173692929
    rotMatrix15.Zx = -0.74210750071903264
    rotMatrix15.Zy = 0.56922081583642037
    rotMatrix15.Zz = 0.35392671585382068
    translation15 = NXOpen.Point3d(-9.2939953001484614, 2.720791550679527, -41.705785154022486)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix15, translation15, 1.7518160999501446)
    
    theSession.UndoToMark(markId96, None)
    
    theSession.DeleteUndoMark(markId96, None)
    
    extrudeBuilder3.Destroy()
    
    section3.Destroy()
    
    workPart.Expressions.Delete(expression38)
    
    workPart.Expressions.Delete(expression39)
    
    theSession.UndoToMark(markId92, None)
    
    theSession.DeleteUndoMark(markId92, None)
    
    markId98 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Delete")
    
    notifyOnDelete1 = theSession.Preferences.Modeling.NotifyOnDelete
    
    theSession.UpdateManager.ClearErrorList()
    
    markId99 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Delete")
    
    objects1 = [NXOpen.TaggedObject.Null] * 1 
    objects1[0] = fillets1[0]
    nErrs6 = theSession.UpdateManager.AddObjectsToDeleteList(objects1)
    
    notifyOnDelete2 = theSession.Preferences.Modeling.NotifyOnDelete
    
    id1 = theSession.NewestVisibleUndoMark
    
    nErrs7 = theSession.UpdateManager.DoUpdate(id1)
    
    theSession.DeleteUndoMark(markId98, None)
    
    markId100 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Delete")
    
    notifyOnDelete3 = theSession.Preferences.Modeling.NotifyOnDelete
    
    theSession.UpdateManager.ClearErrorList()
    
    markId101 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Delete")
    
    objects2 = [NXOpen.TaggedObject.Null] * 1 
    objects2[0] = line12
    nErrs8 = theSession.UpdateManager.AddObjectsToDeleteList(objects2)
    
    notifyOnDelete4 = theSession.Preferences.Modeling.NotifyOnDelete
    
    id2 = theSession.NewestVisibleUndoMark
    
    nErrs9 = theSession.UpdateManager.DoUpdate(id2)
    
    theSession.DeleteUndoMark(markId100, None)
    
    markId102 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Delete")
    
    notifyOnDelete5 = theSession.Preferences.Modeling.NotifyOnDelete
    
    theSession.UpdateManager.ClearErrorList()
    
    markId103 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Delete")
    
    objects3 = [NXOpen.TaggedObject.Null] * 1 
    objects3[0] = line14
    nErrs10 = theSession.UpdateManager.AddObjectsToDeleteList(objects3)
    
    notifyOnDelete6 = theSession.Preferences.Modeling.NotifyOnDelete
    
    id3 = theSession.NewestVisibleUndoMark
    
    nErrs11 = theSession.UpdateManager.DoUpdate(id3)
    
    theSession.DeleteUndoMark(markId102, None)
    
    markId104 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Delete")
    
    notifyOnDelete7 = theSession.Preferences.Modeling.NotifyOnDelete
    
    theSession.UpdateManager.ClearErrorList()
    
    markId105 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Delete")
    
    objects4 = [NXOpen.TaggedObject.Null] * 1 
    objects4[0] = line11
    nErrs12 = theSession.UpdateManager.AddObjectsToDeleteList(objects4)
    
    notifyOnDelete8 = theSession.Preferences.Modeling.NotifyOnDelete
    
    id4 = theSession.NewestVisibleUndoMark
    
    nErrs13 = theSession.UpdateManager.DoUpdate(id4)
    
    theSession.DeleteUndoMark(markId104, None)
    
    rotMatrix16 = NXOpen.Matrix3x3()
    
    rotMatrix16.Xx = -0.057968478453975833
    rotMatrix16.Xy = -0.96749116579093497
    rotMatrix16.Xz = -0.24617168728801911
    rotMatrix16.Yx = 0.24612441154774334
    rotMatrix16.Yy = -0.25282511232160521
    rotMatrix16.Yz = 0.93568276494752545
    rotMatrix16.Zx = -0.96750319355855885
    rotMatrix16.Zy = -0.0063487554738618293
    rotMatrix16.Zz = 0.25277908093417317
    translation16 = NXOpen.Point3d(-6.2166040657162265, 2.5555719915506874, -39.379526895299733)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix16, translation16, 1.7518160999501446)
    
    marksRecycled1, undoUnavailable1 = theSession.UndoLastNVisibleMarks(1)
    
    marksRecycled2, undoUnavailable2 = theSession.UndoLastNVisibleMarks(1)
    
    marksRecycled3, undoUnavailable3 = theSession.UndoLastNVisibleMarks(1)
    
    marksRecycled4, undoUnavailable4 = theSession.UndoLastNVisibleMarks(1)
    
    rotMatrix17 = NXOpen.Matrix3x3()
    
    rotMatrix17.Xx = -0.18131595445763743
    rotMatrix17.Xy = -0.95896593640502859
    rotMatrix17.Xz = -0.21796526666867053
    rotMatrix17.Yx = 0.099965036397754031
    rotMatrix17.Yy = -0.2384632704780566
    rotMatrix17.Yz = 0.96599288824033624
    rotMatrix17.Zx = -0.97833098497242488
    rotMatrix17.Zy = 0.15336101671460628
    rotMatrix17.Zz = 0.13910026022675395
    translation17 = NXOpen.Point3d(-6.6599237197621246, 2.0791884917229879, -37.592839525481935)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix17, translation17, 1.7518160999501446)
    
    markId106 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId107 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Sketch Drag")
    
    theSession.SetUndoMarkVisibility(markId107, "Sketch Drag", NXOpen.Session.MarkVisibility.Visible)
    
    radiusDimension1 = theSession.ActiveSketch.FindObject("ENTITY 26 1 1")
    theSession.UpdateManager.LogForUpdate(radiusDimension1)
    
    startPoint21 = NXOpen.Point3d(-45.000000000000014, 29.000000000000014, 40.0)
    endPoint21 = NXOpen.Point3d(-45.000000000000014, 29.252666118052279, 40.0)
    line13.SetEndpoints(startPoint21, endPoint21)
    
    center1 = NXOpen.Point3d(-45.000000000000014, 29.252666118052279, 14.252666118052279)
    fillets1[0].SetParameters(25.747333881947721, center1, ( 90.0 * math.pi/180.0 ), ( 180.0 * math.pi/180.0 ))
    
    startPoint22 = NXOpen.Point3d(-45.000000000000014, 55.0, 14.252666118052257)
    endPoint22 = NXOpen.Point3d(-45.000000000000014, 55.0, 0.0)
    line14.SetEndpoints(startPoint22, endPoint22)
    
    sketchTangentConstraint1 = theSession.ActiveSketch.FindObject("Tangent [Curve Line14] [Curve Arc1]")
    helpPoint1_2 = NXOpen.Point3d(0.0, 0.0, 0.0)
    helpPoint2_2 = NXOpen.Point3d(-45.000000000000014, 55.0, 14.252666118052279)
    sketchTangentConstraint1.SetHelpPoints(False, True, helpPoint1_2, helpPoint2_2)
    
    sketchTangentConstraint2 = theSession.ActiveSketch.FindObject("Tangent [Curve Line13] [Curve Arc1]")
    helpPoint1_3 = NXOpen.Point3d(0.0, 0.0, 0.0)
    helpPoint2_3 = NXOpen.Point3d(-45.000000000000014, 29.252666118052279, 40.0)
    sketchTangentConstraint2.SetHelpPoints(False, True, helpPoint1_3, helpPoint2_3)
    
    nErrs14 = theSession.UpdateManager.DoUpdate(markId107)
    
    geoms11 = [NXOpen.SmartObject.Null] * 3 
    geoms11[0] = line13
    geoms11[1] = fillets1[0]
    geoms11[2] = line14
    theSession.ActiveSketch.UpdateGeometryDisplay(geoms11)
    
    geoms12 = [NXOpen.SmartObject.Null] * 3 
    geoms12[0] = line13
    geoms12[1] = fillets1[0]
    geoms12[2] = line14
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms12)
    
    geoms13 = [NXOpen.SmartObject.Null] * 3 
    geoms13[0] = line13
    geoms13[1] = fillets1[0]
    geoms13[2] = line14
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms13)
    
    markId108 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Delete")
    
    notifyOnDelete9 = theSession.Preferences.Modeling.NotifyOnDelete
    
    theSession.UpdateManager.ClearErrorList()
    
    markId109 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "起點")
    
    theSession.SetUndoMarkName(markId109, "類選取 對話方塊")
    
    markId110 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "類選取")
    
    theSession.DeleteUndoMark(markId110, None)
    
    markId111 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "類選取")
    
    theSession.DeleteUndoMark(markId111, None)
    
    theSession.SetUndoMarkName(markId109, "類選取")
    
    theSession.DeleteUndoMark(markId109, None)
    
    markId112 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Delete")
    
    objects5 = [NXOpen.TaggedObject.Null] * 2 
    objects5[0] = line11
    objects5[1] = line12
    nErrs15 = theSession.UpdateManager.AddObjectsToDeleteList(objects5)
    
    notifyOnDelete10 = theSession.Preferences.Modeling.NotifyOnDelete
    
    id5 = theSession.NewestVisibleUndoMark
    
    nErrs16 = theSession.UpdateManager.DoUpdate(id5)
    
    theSession.DeleteUndoMark(markId108, None)
    
    markId113 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Delete")
    
    notifyOnDelete11 = theSession.Preferences.Modeling.NotifyOnDelete
    
    theSession.UpdateManager.ClearErrorList()
    
    markId114 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "起點")
    
    theSession.SetUndoMarkName(markId114, "類選取 對話方塊")
    
    theSession.SetUndoMarkName(markId114, "類選取")
    
    theSession.DeleteUndoMark(markId114, None)
    
    theSession.DeleteUndoMark(markId113, None)
    
    markId115 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId116 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId116, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    startPoint23 = NXOpen.Point3d(-45.000000000000014, 55.0, 14.252666118052257)
    endPoint23 = NXOpen.Point3d(-45.000000000000014, 54.999999999999986, 40.0)
    line15 = workPart.Curves.CreateLine(startPoint23, endPoint23)
    
    theSession.ActiveSketch.AddGeometry(line15, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_18 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_18.Geometry = line15
    geom1_18.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom1_18.SplineDefiningPointIndex = 0
    geom2_18 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_18.Geometry = line14
    geom2_18.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_18.SplineDefiningPointIndex = 0
    sketchGeometricConstraint33 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_18, geom2_18)
    
    conGeom1_13 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_13.Geometry = line15
    conGeom1_13.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_13.SplineDefiningPointIndex = 0
    conGeom2_13 = NXOpen.Sketch.ConstraintGeometry()
    
    edge4 = extrude1.FindObject("EDGE * 140 EXTRUDE(4) 140 {(-45,55,40)(-45,55,20)(-45,55,-0) EXTRUDE(2)}")
    conGeom2_13.Geometry = edge4
    conGeom2_13.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_13.SplineDefiningPointIndex = 0
    sketchGeometricConstraint34 = theSession.ActiveSketch.CreateCollinearConstraint(conGeom1_13, conGeom2_13)
    
    conGeom1_14 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_14.Geometry = line15
    conGeom1_14.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_14.SplineDefiningPointIndex = 0
    conGeom2_14 = NXOpen.Sketch.ConstraintGeometry()
    
    extrude2 = feature4
    edge5 = extrude2.FindObject("EDGE * 140 EXTRUDE(2) 130 {(-45,55,40)(-36.9785339613075,50.3076708532192,40)(-28.9570679226151,45.6153417064383,40) EXTRUDE(2)}")
    conGeom2_14.Geometry = edge5
    conGeom2_14.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_14.SplineDefiningPointIndex = 0
    sketchGeometricConstraint35 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_14, conGeom2_14)
    
    geom1_19 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_19.Geometry = line15
    geom1_19.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_19.SplineDefiningPointIndex = 0
    geom2_19 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_19.Geometry = line9
    geom2_19.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom2_19.SplineDefiningPointIndex = 0
    sketchGeometricConstraint36 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_19, geom2_19)
    
    theSession.ActiveSketch.Preferences.ContinuousAutoDimensioningSetting = False
    
    theSession.ActiveSketch.Update()
    
    theSession.ActiveSketch.Preferences.ContinuousAutoDimensioningSetting = True
    
    markId117 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId117, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    startPoint24 = NXOpen.Point3d(-45.000000000000014, 54.999999999999986, 40.0)
    endPoint24 = NXOpen.Point3d(-45.000000000000014, 29.252666118052279, 40.0)
    line16 = workPart.Curves.CreateLine(startPoint24, endPoint24)
    
    theSession.ActiveSketch.AddGeometry(line16, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_20 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_20.Geometry = line16
    geom1_20.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom1_20.SplineDefiningPointIndex = 0
    geom2_20 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_20.Geometry = line15
    geom2_20.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom2_20.SplineDefiningPointIndex = 0
    sketchGeometricConstraint37 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_20, geom2_20)
    
    conGeom1_15 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_15.Geometry = line16
    conGeom1_15.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_15.SplineDefiningPointIndex = 0
    conGeom2_15 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_15.Geometry = edge1
    conGeom2_15.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_15.SplineDefiningPointIndex = 0
    sketchGeometricConstraint38 = theSession.ActiveSketch.CreateCollinearConstraint(conGeom1_15, conGeom2_15)
    
    conGeom1_16 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_16.Geometry = line16
    conGeom1_16.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_16.SplineDefiningPointIndex = 0
    conGeom2_16 = NXOpen.Sketch.ConstraintGeometry()
    
    edge6 = extrude2.FindObject("EDGE * 160 * 170 {(22.2811298798623,17.7998260694347,40)(22.2811298798623,17.7998260694347,20)(22.2811298798623,17.7998260694347,-0) EXTRUDE(2)}")
    conGeom2_16.Geometry = edge6
    conGeom2_16.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_16.SplineDefiningPointIndex = 0
    sketchGeometricConstraint39 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_16, conGeom2_16)
    
    geom1_21 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_21.Geometry = line16
    geom1_21.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_21.SplineDefiningPointIndex = 0
    geom2_21 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_21.Geometry = fillets1[0]
    geom2_21.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_21.SplineDefiningPointIndex = 0
    sketchGeometricConstraint40 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_21, geom2_21)
    
    geom1_22 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_22.Geometry = line16
    geom1_22.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom1_22.SplineDefiningPointIndex = 0
    geom1Help1 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    geom1Help1.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    geom1Help1.Point.X = -45.000000000000014
    geom1Help1.Point.Y = 29.252666118052279
    geom1Help1.Point.Z = 40.0
    geom1Help1.Parameter = 0.0
    geom2_22 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_22.Geometry = fillets1[0]
    geom2_22.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom2_22.SplineDefiningPointIndex = 0
    geom2Help1 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    geom2Help1.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    geom2Help1.Point.X = -45.000000000000014
    geom2Help1.Point.Y = 29.252666118052279
    geom2Help1.Point.Z = 40.0
    geom2Help1.Parameter = 0.0
    sketchTangentConstraint3 = theSession.ActiveSketch.CreateTangentConstraint(geom1_22, geom1Help1, geom2_22, geom2Help1)
    
    theSession.ActiveSketch.Preferences.ContinuousAutoDimensioningSetting = False
    
    theSession.ActiveSketch.Update()
    
    theSession.ActiveSketch.Preferences.ContinuousAutoDimensioningSetting = True
    
    inferredConstraintsBuilder1 = workPart.Sketches.CreateInferredConstraintsBuilder()
    
    rules4 = inferredConstraintsBuilder1.GetRules()
    
    rules5 = [None] * 5 
    rules5[0] = NXOpen.Sketch.AutoDimensioningRule.Symmetric
    rules5[1] = NXOpen.Sketch.AutoDimensioningRule.AdjacentAngle
    rules5[2] = NXOpen.Sketch.AutoDimensioningRule.Length
    rules5[3] = NXOpen.Sketch.AutoDimensioningRule.HorizontalVertical
    rules5[4] = NXOpen.Sketch.AutoDimensioningRule.ReferenceAxes
    inferredConstraintsBuilder1.SetRules(rules5)
    
    nXObject20 = inferredConstraintsBuilder1.Commit()
    
    theSession.ActiveSketch.Update()
    
    rules6 = [None] * 5 
    rules6[0] = NXOpen.Sketch.AutoDimensioningRule.Symmetric
    rules6[1] = NXOpen.Sketch.AutoDimensioningRule.AdjacentAngle
    rules6[2] = NXOpen.Sketch.AutoDimensioningRule.Length
    rules6[3] = NXOpen.Sketch.AutoDimensioningRule.HorizontalVertical
    rules6[4] = NXOpen.Sketch.AutoDimensioningRule.ReferenceAxes
    inferredConstraintsBuilder1.SetRules(rules6)
    
    nXObject21 = inferredConstraintsBuilder1.Commit()
    
    inferredConstraintsBuilder1.Destroy()
    
    markId118 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.ActiveSketch.Update()
    
    theSession.DeleteUndoMark(markId118, "Curve")
    
    markId119 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "起點")
    
    extrudeBuilder4 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section4 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder4.Section = section4
    
    extrudeBuilder4.AllowSelfIntersectingSection(True)
    
    expression40 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder4.DistanceTolerance = 0.01
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies13 = [NXOpen.Body.Null] * 1 
    targetBodies13[0] = NXOpen.Body.Null
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies13)
    
    extrudeBuilder4.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder4.Limits.EndExtend.Value.SetFormula("61")
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies14 = [NXOpen.Body.Null] * 1 
    targetBodies14[0] = body1
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies14)
    
    extrudeBuilder4.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder4.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder4.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder4.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder4 = extrudeBuilder4.SmartVolumeProfile
    
    smartVolumeProfileBuilder4.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder4.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId119, "拉伸 對話方塊")
    
    section4.DistanceTolerance = 0.01
    
    section4.ChainingTolerance = 0.0094999999999999998
    
    section4.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId120 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    curves4 = [NXOpen.ICurve.Null] * 5 
    curves4[0] = line15
    curves4[1] = line14
    curves4[2] = fillets1[0]
    curves4[3] = line13
    curves4[4] = line16
    seedPoint4 = NXOpen.Point3d(-45.000000000000014, 52.486260167817221, 28.903815540501309)
    regionBoundaryRule4 = workPart.ScRuleFactory.CreateRuleRegionBoundary(theSession.ActiveSketch, curves4, seedPoint4, 0.01)
    
    section4.AllowSelfIntersection(True)
    
    rules7 = [None] * 1 
    rules7[0] = regionBoundaryRule4
    helpPoint4 = NXOpen.Point3d(0.0, 0.0, 0.0)
    section4.AddToSection(rules7, NXOpen.NXObject.Null, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint4, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId120, None)
    
    markId121 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId122 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    theSession.DeleteUndoMark(markId122, None)
    
    direction7 = workPart.Directions.CreateDirection(theSession.ActiveSketch, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder4.Direction = direction7
    
    expression41 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId121, None)
    
    rotMatrix18 = NXOpen.Matrix3x3()
    
    rotMatrix18.Xx = -0.87302319168611409
    rotMatrix18.Xy = 0.43412833929995653
    rotMatrix18.Xz = 0.22217806326200695
    rotMatrix18.Yx = 0.10887772417555427
    rotMatrix18.Yy = -0.27057742831339038
    rotMatrix18.Yz = 0.95652156089952611
    rotMatrix18.Zx = 0.47536948572299681
    rotMatrix18.Zy = 0.85925574790278614
    rotMatrix18.Zz = 0.18895346448128433
    translation18 = NXOpen.Point3d(-42.057084350365855, 2.6651519984831999, 3.4817432608252421)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix18, translation18, 1.7518160999501446)
    
    direction8 = extrudeBuilder4.Direction
    
    success3 = direction8.ReverseDirection()
    
    extrudeBuilder4.Direction = direction8
    
    extrudeBuilder4.Limits.EndExtend.Value.SetFormula("109")
    
    markId123 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "拉伸")
    
    extrudeBuilder4.ParentFeatureInternal = False
    
    markId124 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    feature7 = extrudeBuilder4.CommitFeature()
    
    rotMatrix19 = NXOpen.Matrix3x3()
    
    rotMatrix19.Xx = -0.9737868250792453
    rotMatrix19.Xy = -0.22504173414473505
    rotMatrix19.Xz = 0.033097389552860929
    rotMatrix19.Yx = 0.13713263133439835
    rotMatrix19.Yy = -0.46473837162306203
    rotMatrix19.Yz = 0.87476447536719792
    rotMatrix19.Zx = -0.18147688757907285
    rotMatrix19.Zy = 0.85637285327961843
    rotMatrix19.Zz = 0.48341666855864351
    translation19 = NXOpen.Point3d(-38.275470876182879, 4.3002937091297824, -2.4075208207219374)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix19, translation19, 1.7518160999501446)
    
    theSession.SetUndoMarkName(markId119, "拉伸")
    
    expression42 = extrudeBuilder4.Limits.StartExtend.Value
    expression43 = extrudeBuilder4.Limits.EndExtend.Value
    extrudeBuilder4.Destroy()
    
    workPart.Expressions.Delete(expression40)
    
    workPart.Expressions.Delete(expression41)
    
    scaleAboutPoint28 = NXOpen.Point3d(-34.737759670320784, -9.2130579995197976, 0.0)
    viewCenter28 = NXOpen.Point3d(34.737759670320671, 9.213057999519874, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint28, viewCenter28)
    
    scaleAboutPoint29 = NXOpen.Point3d(-43.610991760022266, -13.215452048491533, 0.0)
    viewCenter29 = NXOpen.Point3d(43.610991760022138, 13.215452048491597, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint29, viewCenter29)
    
    scaleAboutPoint30 = NXOpen.Point3d(-55.221710345482698, -19.351197642434059, 0.0)
    viewCenter30 = NXOpen.Point3d(55.221710345482599, 19.351197642434119, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint30, viewCenter30)
    
    scaleAboutPoint31 = NXOpen.Point3d(-70.502076776551149, -32.153666814410258, 0.0)
    viewCenter31 = NXOpen.Point3d(70.502076776551036, 32.153666814410336, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint31, viewCenter31)
    
    scaleAboutPoint32 = NXOpen.Point3d(-56.401661421240888, -25.722933451528171, 0.0)
    viewCenter32 = NXOpen.Point3d(56.401661421240789, 25.722933451528291, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint32, viewCenter32)
    
    scaleAboutPoint33 = NXOpen.Point3d(-45.121329136992742, -20.578346761222523, 0.0)
    viewCenter33 = NXOpen.Point3d(45.121329136992614, 20.578346761222637, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint33, viewCenter33)
    
    scaleAboutPoint34 = NXOpen.Point3d(-36.097063309594198, -16.462677408978017, 0.0)
    viewCenter34 = NXOpen.Point3d(36.097063309594091, 16.46267740897812, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint34, viewCenter34)
    
    scaleAboutPoint35 = NXOpen.Point3d(-28.877650647675338, -13.170141927182394, 0.0)
    viewCenter35 = NXOpen.Point3d(28.877650647675285, 13.170141927182508, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint35, viewCenter35)
    
    scaleAboutPoint36 = NXOpen.Point3d(-23.102120518140286, -10.536113541745907, 0.0)
    viewCenter36 = NXOpen.Point3d(23.102120518140215, 10.536113541746023, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint36, viewCenter36)
    
    scaleAboutPoint37 = NXOpen.Point3d(-18.868342783016679, -7.887585917490509, 0.0)
    viewCenter37 = NXOpen.Point3d(18.868342783016601, 7.8875859174906147, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint37, viewCenter37)
    
    scaleAboutPoint38 = NXOpen.Point3d(-8.9701957493030253, -7.7947907890494426, 0.0)
    viewCenter38 = NXOpen.Point3d(8.970195749302956, 7.7947907890495483, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint38, viewCenter38)
    
    scaleAboutPoint39 = NXOpen.Point3d(-11.212744686628769, -9.8208177600127016, 0.0)
    viewCenter39 = NXOpen.Point3d(11.212744686628703, 9.8208177600128064, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint39, viewCenter39)
    
    scaleAboutPoint40 = NXOpen.Point3d(-14.015930858285975, -12.372683792141995, 0.0)
    viewCenter40 = NXOpen.Point3d(14.015930858285875, 12.37268379214211, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint40, viewCenter40)
    
    scaleAboutPoint41 = NXOpen.Point3d(-16.794951631911623, -17.761567553172625, 0.0)
    viewCenter41 = NXOpen.Point3d(16.794951631911541, 17.761567553172728, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint41, viewCenter41)
    
    scaleAboutPoint42 = NXOpen.Point3d(-20.993689539889527, -22.201959441465803, 0.0)
    viewCenter42 = NXOpen.Point3d(20.993689539889424, 22.201959441465895, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint42, viewCenter42)
    
    scaleAboutPoint43 = NXOpen.Point3d(-26.242111924861906, -27.752449301832254, 0.0)
    viewCenter43 = NXOpen.Point3d(26.242111924861778, 27.75244930183235, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint43, viewCenter43)
    
    rotMatrix20 = NXOpen.Matrix3x3()
    
    rotMatrix20.Xx = 0.0051400497312871773
    rotMatrix20.Xy = -0.99930820449681057
    rotMatrix20.Xz = -0.036833304414913719
    rotMatrix20.Yx = 0.24466447598107288
    rotMatrix20.Yy = -0.034457550386232556
    rotMatrix20.Yz = 0.96899534127584364
    rotMatrix20.Zx = -0.96959418009890663
    rotMatrix20.Zy = -0.013992485366870023
    rotMatrix20.Zz = 0.24431810467419512
    translation20 = NXOpen.Point3d(-39.032829619861609, -7.1530245265617118, 2.3744504569671174)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix20, translation20, 1.1211623039680931)
    
    rotMatrix21 = NXOpen.Matrix3x3()
    
    rotMatrix21.Xx = -0.24662684865267301
    rotMatrix21.Xy = -0.96899240564423317
    rotMatrix21.Xz = 0.015129948032165099
    rotMatrix21.Yx = 0.12794438543107484
    rotMatrix21.Yy = -0.017080779839715565
    rotMatrix21.Yz = 0.99163424769253339
    rotMatrix21.Zx = -0.96062762387947365
    rotMatrix21.Zy = 0.24649942142705242
    rotMatrix21.Zz = 0.12818971673192942
    translation21 = NXOpen.Point3d(-40.072094668803182, -7.6058026548955091, 4.6970182158124061)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix21, translation21, 1.1211623039680931)
    
    
if __name__ == '__main__':
    main()